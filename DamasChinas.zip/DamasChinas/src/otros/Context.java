package otros;

import entidades.Jugador;
import entidades.Partida;

/**
 *
 * @author Jatniel Martínez
 */
public class Context {
  
  private static final Context INSTANCE = new Context();
  
  private Jugador jugador;
  private Partida partida;
  
  public Context() {
    
  }
  
  public static Context getInstance() {
    return INSTANCE;
  }
  
  public void setJugador(Jugador jugador) {
    this.jugador = jugador;
  }
  
  public Jugador getJugador() {
    return jugador;
  }
  
  public void setPartida(Partida partida) {
    this.partida = partida;
  }
  
  public Partida getPartida() {
    return partida;
  }
  
}
