package comunicacion;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import java.net.URISyntaxException;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

/**
 *
 * @author Jatniel Martínez
 */
public class Cliente {
  
  public static void main(String[] args) throws URISyntaxException {
    Socket socket = IO.socket("http://192.168.8.4:5000");
    socket.on(Socket.EVENT_CONNECT, new Emitter.Listener() {
      @Override
      public void call(Object... os) {
        Alert chat = new Alert(AlertType.INFORMATION);
        chat.setTitle("Chat activado");
        chat.setHeaderText("El chat está activado");
        chat.setContentText("Puede chatear mientras juega");
        chat.showAndWait();
      }
    }).on("chatEnJuego", new Emitter.Listener() {
      @Override
      public void call(Object... os) {
        String mensaje = (String)os[0];
        System.out.println(mensaje);
      }
    });
    socket.connect();
  }
  
}
