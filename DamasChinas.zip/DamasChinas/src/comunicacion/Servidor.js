var io = require("socket.io")(5000);

io.on("connection", function(socket){
    socket.on("mensaje", function(mensaje){
        console.log("Escuchando..." + mensaje);
        socket.broadcast.emit("chat", mensaje);
    });
});
