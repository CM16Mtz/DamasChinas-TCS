/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "juego")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Juego.findAll", query = "SELECT j FROM Juego j")
  , @NamedQuery(name = "Juego.findByJugadoridJugador", query = "SELECT j FROM Juego j WHERE j.juegoPK.jugadoridJugador = :jugadoridJugador")
  , @NamedQuery(name = "Juego.findByPartidaidPartida", query = "SELECT j FROM Juego j WHERE j.juegoPK.partidaidPartida = :partidaidPartida")
  , @NamedQuery(name = "Juego.findByColorFichas", query = "SELECT j FROM Juego j WHERE j.colorFichas = :colorFichas")
  , @NamedQuery(name = "Juego.findByFichasLadoOpuesto", query = "SELECT j FROM Juego j WHERE j.fichasLadoOpuesto = :fichasLadoOpuesto")})
public class Juego implements Serializable {

  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected JuegoPK juegoPK;
  @Basic(optional = false)
  @Column(name = "colorFichas")
  private String colorFichas;
  @Basic(optional = false)
  @Column(name = "fichasLadoOpuesto")
  private int fichasLadoOpuesto;
  @JoinColumn(name = "Jugador_idJugador", referencedColumnName = "idJugador", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private Jugador jugador;
  @JoinColumn(name = "Partida_idPartida", referencedColumnName = "idPartida", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private Partida partida;

  public Juego() {
  }

  public Juego(JuegoPK juegoPK) {
    this.juegoPK = juegoPK;
  }

  public Juego(JuegoPK juegoPK, String colorFichas, int fichasLadoOpuesto) {
    this.juegoPK = juegoPK;
    this.colorFichas = colorFichas;
    this.fichasLadoOpuesto = fichasLadoOpuesto;
  }

  public Juego(int jugadoridJugador, int partidaidPartida) {
    this.juegoPK = new JuegoPK(jugadoridJugador, partidaidPartida);
  }

  public JuegoPK getJuegoPK() {
    return juegoPK;
  }

  public void setJuegoPK(JuegoPK juegoPK) {
    this.juegoPK = juegoPK;
  }

  public String getColorFichas() {
    return colorFichas;
  }

  public void setColorFichas(String colorFichas) {
    this.colorFichas = colorFichas;
  }

  public int getFichasLadoOpuesto() {
    return fichasLadoOpuesto;
  }

  public void setFichasLadoOpuesto(int fichasLadoOpuesto) {
    this.fichasLadoOpuesto = fichasLadoOpuesto;
  }

  public Jugador getJugador() {
    return jugador;
  }

  public void setJugador(Jugador jugador) {
    this.jugador = jugador;
  }

  public Partida getPartida() {
    return partida;
  }

  public void setPartida(Partida partida) {
    this.partida = partida;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (juegoPK != null ? juegoPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Juego)) {
      return false;
    }
    Juego other = (Juego) object;
    if ((this.juegoPK == null && other.juegoPK != null) || (this.juegoPK != null && !this.juegoPK.equals(other.juegoPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "entidades.Juego[ juegoPK=" + juegoPK + " ]";
  }
  
}
