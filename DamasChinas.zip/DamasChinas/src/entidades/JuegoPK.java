/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author HP
 */
@Embeddable
public class JuegoPK implements Serializable {

  @Basic(optional = false)
  @Column(name = "Jugador_idJugador")
  private int jugadoridJugador;
  @Basic(optional = false)
  @Column(name = "Partida_idPartida")
  private int partidaidPartida;

  public JuegoPK() {
  }

  public JuegoPK(int jugadoridJugador, int partidaidPartida) {
    this.jugadoridJugador = jugadoridJugador;
    this.partidaidPartida = partidaidPartida;
  }

  public int getJugadoridJugador() {
    return jugadoridJugador;
  }

  public void setJugadoridJugador(int jugadoridJugador) {
    this.jugadoridJugador = jugadoridJugador;
  }

  public int getPartidaidPartida() {
    return partidaidPartida;
  }

  public void setPartidaidPartida(int partidaidPartida) {
    this.partidaidPartida = partidaidPartida;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (int) jugadoridJugador;
    hash += (int) partidaidPartida;
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof JuegoPK)) {
      return false;
    }
    JuegoPK other = (JuegoPK) object;
    if (this.jugadoridJugador != other.jugadoridJugador) {
      return false;
    }
    if (this.partidaidPartida != other.partidaidPartida) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "entidades.JuegoPK[ jugadoridJugador=" + jugadoridJugador + ", partidaidPartida=" + partidaidPartida + " ]";
  }
  
}
