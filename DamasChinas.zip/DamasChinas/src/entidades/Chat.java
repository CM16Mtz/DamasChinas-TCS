/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "chat")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Chat.findAll", query = "SELECT c FROM Chat c")
  , @NamedQuery(name = "Chat.findByIdChat", query = "SELECT c FROM Chat c WHERE c.idChat = :idChat")
  , @NamedQuery(name = "Chat.findByMensaje", query = "SELECT c FROM Chat c WHERE c.mensaje = :mensaje")})
public class Chat implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @Column(name = "idChat")
  private String idChat;
  @Basic(optional = false)
  @Column(name = "mensaje")
  private String mensaje;
  @JoinColumn(name = "Jugador_idJugador", referencedColumnName = "idJugador")
  @ManyToOne(optional = false)
  private Jugador jugadoridJugador;
  @JoinColumn(name = "Partida_idPartida", referencedColumnName = "idPartida")
  @ManyToOne(optional = false)
  private Partida partidaidPartida;

  public Chat() {
  }

  public Chat(String idChat) {
    this.idChat = idChat;
  }

  public Chat(String idChat, String mensaje) {
    this.idChat = idChat;
    this.mensaje = mensaje;
  }

  public String getIdChat() {
    return idChat;
  }

  public void setIdChat(String idChat) {
    this.idChat = idChat;
  }

  public String getMensaje() {
    return mensaje;
  }

  public void setMensaje(String mensaje) {
    this.mensaje = mensaje;
  }

  public Jugador getJugadoridJugador() {
    return jugadoridJugador;
  }

  public void setJugadoridJugador(Jugador jugadoridJugador) {
    this.jugadoridJugador = jugadoridJugador;
  }

  public Partida getPartidaidPartida() {
    return partidaidPartida;
  }

  public void setPartidaidPartida(Partida partidaidPartida) {
    this.partidaidPartida = partidaidPartida;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (idChat != null ? idChat.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Chat)) {
      return false;
    }
    Chat other = (Chat) object;
    if ((this.idChat == null && other.idChat != null) || (this.idChat != null && !this.idChat.equals(other.idChat))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "entidades.Chat[ idChat=" + idChat + " ]";
  }
  
}
