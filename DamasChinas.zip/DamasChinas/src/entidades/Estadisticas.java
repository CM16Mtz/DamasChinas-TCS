/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "estadisticas")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Estadisticas.findAll", query = "SELECT e FROM Estadisticas e")
  , @NamedQuery(name = "Estadisticas.findByIdEstadisticas", query = "SELECT e FROM Estadisticas e WHERE e.idEstadisticas = :idEstadisticas")
  , @NamedQuery(name = "Estadisticas.findByPartidasJugadas", query = "SELECT e FROM Estadisticas e WHERE e.partidasJugadas = :partidasJugadas")
  , @NamedQuery(name = "Estadisticas.findByPartidasGanadas", query = "SELECT e FROM Estadisticas e WHERE e.partidasGanadas = :partidasGanadas")
  , @NamedQuery(name = "Estadisticas.findByFechaRegistro", query = "SELECT e FROM Estadisticas e WHERE e.fechaRegistro = :fechaRegistro")})
public class Estadisticas implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "idEstadisticas")
  private Integer idEstadisticas;
  @Basic(optional = false)
  @Column(name = "partidasJugadas")
  private int partidasJugadas;
  @Basic(optional = false)
  @Column(name = "partidasGanadas")
  private int partidasGanadas;
  @Basic(optional = false)
  @Column(name = "fechaRegistro")
  @Temporal(TemporalType.TIMESTAMP)
  private Date fechaRegistro;
  @JoinColumn(name = "Jugador_idJugador", referencedColumnName = "idJugador")
  @ManyToOne(optional = false)
  private Jugador jugadoridJugador;

  public Estadisticas() {
  }

  public Estadisticas(Integer idEstadisticas) {
    this.idEstadisticas = idEstadisticas;
  }

  public Estadisticas(Integer idEstadisticas, int partidasJugadas, int partidasGanadas, Date fechaRegistro) {
    this.idEstadisticas = idEstadisticas;
    this.partidasJugadas = partidasJugadas;
    this.partidasGanadas = partidasGanadas;
    this.fechaRegistro = fechaRegistro;
  }

  public Integer getIdEstadisticas() {
    return idEstadisticas;
  }

  public void setIdEstadisticas(Integer idEstadisticas) {
    this.idEstadisticas = idEstadisticas;
  }

  public int getPartidasJugadas() {
    return partidasJugadas;
  }

  public void setPartidasJugadas(int partidasJugadas) {
    this.partidasJugadas = partidasJugadas;
  }

  public int getPartidasGanadas() {
    return partidasGanadas;
  }

  public void setPartidasGanadas(int partidasGanadas) {
    this.partidasGanadas = partidasGanadas;
  }

  public Date getFechaRegistro() {
    return fechaRegistro;
  }

  public void setFechaRegistro(Date fechaRegistro) {
    this.fechaRegistro = fechaRegistro;
  }

  public Jugador getJugadoridJugador() {
    return jugadoridJugador;
  }

  public void setJugadoridJugador(Jugador jugadoridJugador) {
    this.jugadoridJugador = jugadoridJugador;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (idEstadisticas != null ? idEstadisticas.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Estadisticas)) {
      return false;
    }
    Estadisticas other = (Estadisticas) object;
    if ((this.idEstadisticas == null && other.idEstadisticas != null) || (this.idEstadisticas != null && !this.idEstadisticas.equals(other.idEstadisticas))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "entidades.Estadisticas[ idEstadisticas=" + idEstadisticas + " ]";
  }
  
}
