/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "partida")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Partida.findAll", query = "SELECT p FROM Partida p")
  , @NamedQuery(name = "Partida.findByIdPartida", query = "SELECT p FROM Partida p WHERE p.idPartida = :idPartida")
  , @NamedQuery(name = "Partida.findByNombrePartida", query = "SELECT p FROM Partida p WHERE p.nombrePartida = :nombrePartida")
  , @NamedQuery(name = "Partida.findByNumJugadores", query = "SELECT p FROM Partida p WHERE p.numJugadores = :numJugadores")
  , @NamedQuery(name = "Partida.findByContrasena", query = "SELECT p FROM Partida p WHERE p.contrasena = :contrasena")})
public class Partida implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "idPartida")
  private Integer idPartida;
  @Basic(optional = false)
  @Column(name = "nombrePartida")
  private String nombrePartida;
  @Basic(optional = false)
  @Column(name = "numJugadores")
  private int numJugadores;
  @Column(name = "contrasena")
  private String contrasena;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "partidaidPartida")
  private List<Chat> chatList;
  @OneToMany(cascade = CascadeType.ALL, mappedBy = "partida")
  private List<Juego> juegoList;

  public Partida() {
  }

  public Partida(Integer idPartida) {
    this.idPartida = idPartida;
  }

  public Partida(Integer idPartida, String nombrePartida, int numJugadores) {
    this.idPartida = idPartida;
    this.nombrePartida = nombrePartida;
    this.numJugadores = numJugadores;
  }

  public Integer getIdPartida() {
    return idPartida;
  }

  public void setIdPartida(Integer idPartida) {
    this.idPartida = idPartida;
  }

  public String getNombrePartida() {
    return nombrePartida;
  }

  public void setNombrePartida(String nombrePartida) {
    this.nombrePartida = nombrePartida;
  }

  public int getNumJugadores() {
    return numJugadores;
  }

  public void setNumJugadores(int numJugadores) {
    this.numJugadores = numJugadores;
  }

  public String getContrasena() {
    return contrasena;
  }

  public void setContrasena(String contrasena) {
    this.contrasena = contrasena;
  }

  @XmlTransient
  public List<Chat> getChatList() {
    return chatList;
  }

  public void setChatList(List<Chat> chatList) {
    this.chatList = chatList;
  }

  @XmlTransient
  public List<Juego> getJuegoList() {
    return juegoList;
  }

  public void setJuegoList(List<Juego> juegoList) {
    this.juegoList = juegoList;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (idPartida != null ? idPartida.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Partida)) {
      return false;
    }
    Partida other = (Partida) object;
    if ((this.idPartida == null && other.idPartida != null) || (this.idPartida != null && !this.idPartida.equals(other.idPartida))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "entidades.Partida[ idPartida=" + idPartida + " ]";
  }
  
}
