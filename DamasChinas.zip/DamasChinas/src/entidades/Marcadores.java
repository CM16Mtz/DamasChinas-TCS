/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "marcadores")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Marcadores.findAll", query = "SELECT m FROM Marcadores m")
  , @NamedQuery(name = "Marcadores.findByIdMarcadores", query = "SELECT m FROM Marcadores m WHERE m.idMarcadores = :idMarcadores")
  , @NamedQuery(name = "Marcadores.findByPuntuacion", query = "SELECT m FROM Marcadores m WHERE m.puntuacion = :puntuacion")})
public class Marcadores implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Basic(optional = false)
  @Column(name = "idMarcadores")
  private Integer idMarcadores;
  @Basic(optional = false)
  @Column(name = "Puntuacion")
  private int puntuacion;
  @JoinColumn(name = "Jugador_idJugador", referencedColumnName = "idJugador")
  @ManyToOne(optional = false)
  private Jugador jugadoridJugador;

  public Marcadores() {
  }

  public Marcadores(Integer idMarcadores) {
    this.idMarcadores = idMarcadores;
  }

  public Marcadores(Integer idMarcadores, int puntuacion) {
    this.idMarcadores = idMarcadores;
    this.puntuacion = puntuacion;
  }

  public Integer getIdMarcadores() {
    return idMarcadores;
  }

  public void setIdMarcadores(Integer idMarcadores) {
    this.idMarcadores = idMarcadores;
  }

  public int getPuntuacion() {
    return puntuacion;
  }

  public void setPuntuacion(int puntuacion) {
    this.puntuacion = puntuacion;
  }

  public Jugador getJugadoridJugador() {
    return jugadoridJugador;
  }

  public void setJugadoridJugador(Jugador jugadoridJugador) {
    this.jugadoridJugador = jugadoridJugador;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (idMarcadores != null ? idMarcadores.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Marcadores)) {
      return false;
    }
    Marcadores other = (Marcadores) object;
    if ((this.idMarcadores == null && other.idMarcadores != null) || (this.idMarcadores != null && !this.idMarcadores.equals(other.idMarcadores))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "entidades.Marcadores[ idMarcadores=" + idMarcadores + " ]";
  }
  
}
