package main;

import java.util.Locale;
import java.util.ResourceBundle;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Jatniel Martínez
 */
public final class DamasChinas extends Application {

  @Override
  public void start(Stage primaryStage) throws Exception {
    Locale locale = new Locale("es");
    Parent iniciarSesionRoot = FXMLLoader.load(getClass().getResource("/gui/IniciarSesion.fxml"),
        ResourceBundle.getBundle("idiomas.IniciarSesion", locale));
    Scene iniciarSesionScene = new Scene(iniciarSesionRoot);
    primaryStage.setScene(iniciarSesionScene);
    primaryStage.show();
  }
  
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    launch(args);
  }
  
}
