package gui;

import entidades.Jugador;
import entidades.Partida;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import otros.Context;

/**
 * FXML Controller de la clase SeleccionarColor
 * @author Jatniel Martínez
 */
public class SeleccionarColorController implements Initializable {
  
  @FXML private Label label;
  @FXML private RadioButton rdbRojo;
  @FXML private RadioButton rdbNaranja;
  @FXML private RadioButton rdbAmarillo;
  @FXML private RadioButton rdbVerde;
  @FXML private RadioButton rdbAzul;
  @FXML private RadioButton rdbVioleta;
  @FXML private Button btnSiguiente;
  private ToggleGroup colores;
  Jugador jugador = new Jugador();
  Partida partida = new Partida();

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    jugador = Context.getInstance().getJugador();
    partida = Context.getInstance().getPartida();
    colores = new ToggleGroup();
    rdbRojo.setToggleGroup(colores);
    rdbNaranja.setToggleGroup(colores);
    rdbAmarillo.setToggleGroup(colores);
    rdbVerde.setToggleGroup(colores);
    rdbAzul.setToggleGroup(colores);
    rdbVioleta.setToggleGroup(colores);
  }
  
  @FXML
  void seleccionarColor(ActionEvent event) throws IOException {
    colores.selectedToggleProperty().addListener(
        (ObservableValue<? extends Toggle> ov, Toggle oldToggle, Toggle newToggle) -> {
      if (colores.getSelectedToggle() != null) {
        if (rdbRojo.isSelected()) {
          
        } else if (rdbNaranja.isSelected()) {
          
        } else if (rdbAmarillo.isSelected()) {
          
        } else if (rdbVerde.isSelected()) {
          
        } else if (rdbAzul.isSelected()) {
          
        } else if (rdbVioleta.isSelected()) {
          
        }
      }
    });
    Context.getInstance().setJugador(jugador);
    Context.getInstance().setPartida(partida);
    Stage tableroStage = new Stage();
    Parent tableroRoot = FXMLLoader.load(getClass().getResource("/gui/Tablero.fxml"),
        ResourceBundle.getBundle("idiomas.Tablero", Locale.getDefault()));
    Scene tableroScene = new Scene(tableroRoot);
    tableroStage.setScene(tableroScene);
    tableroStage.show();
  }
  
}
