package gui;

import entidades.Jugador;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import otros.Context;

/**
 * FXML Controller de la GUI MenuInvitado
 * @author Jatniel Martínez
 */
public class MenuInvitadoController implements Initializable {
  
  @FXML private Label lblBienvenido;
  @FXML private Button btnUnirse;
  @FXML private Button btnMarcadores;
  @FXML private Button btnIdioma;
  @FXML private Button btnSalir;
  Jugador jugador = new Jugador();

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    jugador = Context.getInstance().getJugador();
  }
  
  @FXML
  void unirseAPartida(ActionEvent event) throws IOException {
    Stage menuInvitadoStage = (Stage) btnUnirse.getScene().getWindow();
    menuInvitadoStage.hide();
    Stage unirseAPartidaStage = new Stage();
    Parent unirseAPartidaRoot = FXMLLoader.load(getClass().getResource("/gui/UnirseAPartida.fxml"),
        ResourceBundle.getBundle("idiomas.UnirseAPartida", Locale.getDefault()));
    Scene unirseAPartidaScene = new Scene(unirseAPartidaRoot);
    unirseAPartidaStage.setScene(unirseAPartidaScene);
    unirseAPartidaStage.show();
  }
  
  @FXML
  void consultarMarcadores(ActionEvent event) throws IOException {
    Stage menuInvitadoStage = (Stage) btnMarcadores.getScene().getWindow();
    menuInvitadoStage.hide();
    Stage marcadoresStage = new Stage();
    Parent marcadoresRoot = FXMLLoader.load(getClass().getResource("/gui/Marcadores.fxml"),
        ResourceBundle.getBundle("idiomas.Marcadores", Locale.getDefault()));
    Scene marcadoresScene = new Scene(marcadoresRoot);
    marcadoresStage.setScene(marcadoresScene);
    marcadoresStage.show();
  }
  
  @FXML
  void cambiarIdioma(ActionEvent event) throws IOException {
    Stage menuInvitadoStage = (Stage) btnIdioma.getScene().getWindow();
    menuInvitadoStage.hide();
    Stage cambiarIdiomaStage = new Stage();
    Parent cambiarIdiomaRoot = FXMLLoader.load(getClass().getResource("/gui/CambiarIdioma.fxml"),
        ResourceBundle.getBundle("idiomas.CambiarIdioma", Locale.getDefault()));
    Scene cambiarIdiomaScene = new Scene(cambiarIdiomaRoot);
    cambiarIdiomaStage.setScene(cambiarIdiomaScene);
    cambiarIdiomaStage.show();
  }
  
  @FXML
  void cerrarSesion(ActionEvent event) throws IOException {
    Stage menuInvitadoStage = (Stage) btnSalir.getScene().getWindow();
    menuInvitadoStage.close();
    Stage iniciarSesionStage = new Stage();
    Parent iniciarSesionRoot = FXMLLoader.load(getClass().getResource("/gui/IniciarSesion.fxml"),
        ResourceBundle.getBundle("idiomas.IniciarSesion", Locale.getDefault()));
    Scene iniciarSesionScene = new Scene(iniciarSesionRoot);
    iniciarSesionStage.setScene(iniciarSesionScene);
    iniciarSesionStage.show();
  }
  
}
