package gui;

import controladoresjpa.JugadorJpaController;
import entidades.Jugador;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.persistence.Persistence;

/**
 * FXML Controller de la GUI Registrarse
 * @author Jatniel Martínez
 */
public class RegistrarseController implements Initializable {
  
  @FXML private Label lblCorreo;
  @FXML private Label lblUsuario;
  @FXML private Label lblContrasena;
  @FXML private TextField txfCorreo;
  @FXML private TextField txfUsuario;
  @FXML private PasswordField pwfContrasena;
  @FXML private Button btnRegistrar;
  @FXML private Button btnCancelar;

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    // TODO
  }
  
  @FXML
  void registrarJugador(ActionEvent event) throws IOException {
    String correo = txfCorreo.getText();
    String usuario = txfUsuario.getText();
    String contrasena = pwfContrasena.getText();
    if (correo != null && usuario != null && contrasena != null) {
      Jugador nuevoJugador = new Jugador(0, usuario, correo, "Registrado");
      nuevoJugador.setContrasena(contrasena);
      JugadorJpaController controller =
          new JugadorJpaController(Persistence.createEntityManagerFactory("DamasChinasPU"));
      controller.create(nuevoJugador);
      Alert info = new Alert(AlertType.INFORMATION);
      info.setTitle("Registrado");
      info.setHeaderText("Te has registrado con éxito");
      info.setContentText("Te enviamos un correo de verificación de tu cuenta");
      info.showAndWait();
      enviarCorreo(correo);
      Stage registrarseStage = (Stage) btnRegistrar.getScene().getWindow();
      registrarseStage.close();
      Stage iniciarSesionStage = new Stage();
      Parent iniciarSesionRoot = FXMLLoader.load(getClass().getResource("/gui/IniciarSesion.fxml"),
          ResourceBundle.getBundle("idiomas.IniciarSesion", Locale.getDefault()));
      Scene iniciarSesionScene = new Scene(iniciarSesionRoot);
      iniciarSesionStage.setScene(iniciarSesionScene);
      iniciarSesionStage.show();
    } else {
      Alert advertencia = new Alert(AlertType.WARNING);
      advertencia.setTitle("Datos inválidos");
      advertencia.setHeaderText(null);
      advertencia.setContentText("La información ingresada no es la correcta");
      advertencia.showAndWait();
    }
  }
  
  @FXML
  void regresar(ActionEvent event) throws IOException {
    Stage registrarseStage = (Stage) btnCancelar.getScene().getWindow();
    registrarseStage.close();
    Stage iniciarSesionStage = new Stage();
    Parent iniciarSesionRoot = FXMLLoader.load(getClass().getResource("/gui/IniciarSesion.fxml"),
        ResourceBundle.getBundle("idiomas.IniciarSesion", Locale.getDefault()));
    Scene iniciarSesionScene = new Scene(iniciarSesionRoot);
    iniciarSesionStage.setScene(iniciarSesionScene);
    iniciarSesionStage.show();
  }
  
  /**
   * Método para enviar correo por GMail
   * @param destinatario el correo con el que se registró el jugador
   */
  public void enviarCorreo(String destinatario) {
    Properties p = new Properties();
    p.put("mail.smtp.host", "smtp.gmail.com");    //Host de Google
    p.put("mail.smtp.starttls.enable", "true");    //Conexión segura al servidor
    p.put("mail.smtp.port", "587");    //Puerto SMTP seguro de Google
    p.put("mail.smtp.auth", "true");    //Habilitar autenticación de credenciales
    Session s = Session.getInstance(p, new Authenticator() {
      @Override
      protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication("jatnielmtz@gmail.com", "CleoViridia");
      }
    });
    try {
      Message mensaje = new MimeMessage(s);
      mensaje.setFrom(new InternetAddress("jatnielmtz@gmail.com"));
      //mensaje.setFrom(new InternetAddress((String)p.get("mail.smtp.mail.sender")));
      mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
      mensaje.setSubject("Registro a DamasChinas - JavaFX");
      mensaje.setText(
          "Este es un mensaje para verificar que usted se registró en el juego de damas chinas");
      Transport.send(mensaje);
    } catch (MessagingException ex) {
      Alert error = new Alert(AlertType.ERROR);
      error.setTitle("Error de envío");
      error.setHeaderText(null);
      error.setContentText("Se produjo un error al enviarte un correo de verificación");
      error.showAndWait();
      ex.printStackTrace();
    }
  }
  
}
