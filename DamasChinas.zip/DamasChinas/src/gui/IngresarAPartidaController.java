package gui;

import controladoresjpa.PartidaJpaController;
import entidades.Jugador;
import entidades.Partida;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import javax.persistence.Persistence;
import otros.Context;

/**
 * FXML Controller de la GUI IngresarAPartida
 * @author Jatniel Martínez
 */
public class IngresarAPartidaController implements Initializable {
  
  @FXML private Label label;
  @FXML private PasswordField pwfClave;
  @FXML private Button btnIngresar;
  @FXML private Button btnCancelar;
  Jugador jugador = new Jugador();
  Partida partida = new Partida();

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    jugador = Context.getInstance().getJugador();
    partida = Context.getInstance().getPartida();
  }
  
  @FXML
  void ingresarAPartida(ActionEvent event) throws IOException {
    String contrasena = pwfClave.getText();
    Partida partida = new Partida();
    partida.setContrasena(contrasena);
    PartidaJpaController controller = 
        new PartidaJpaController(Persistence.createEntityManagerFactory("DamasChinasPU"));
    Partida auxiliar = controller.validarContrasena(partida);
    if (partida == auxiliar) {
      Context.getInstance().setJugador(jugador);
      Context.getInstance().setPartida(partida);
      Stage ingresarAPartidaStage = (Stage) btnIngresar.getScene().getWindow();
      ingresarAPartidaStage.close();
      Stage seleccionarColorStage = new Stage();
      Parent seleccionarColorRoot = FXMLLoader.load(
          getClass().getResource("/gui/SeleccionarColor.fxml"),
          ResourceBundle.getBundle("idiomas.SeleccionarColor", Locale.getDefault()));
      Scene seleccionarColorScene = new Scene(seleccionarColorRoot);
      seleccionarColorStage.setScene(seleccionarColorScene);
      seleccionarColorStage.show();
    } else {
      Alert denegado = new Alert(AlertType.ERROR);
      if (Locale.getDefault().equals(Locale.ENGLISH)) {
        denegado.setTitle("Denied!");
        denegado.setHeaderText("The password you typed is incorrect");
        denegado.setContentText("Please, type the correct password");
        denegado.showAndWait();
      } else if (Locale.getDefault().equals(new Locale("es"))) {
        denegado.setTitle("¡Denegado!");
        denegado.setHeaderText("La contraseña que ingresaste es incorrecta");
        denegado.setContentText("Por favor, ingrese la contraseña correcta");
        denegado.showAndWait();
      }
    }
  }
  
  @FXML
  void cancelar(ActionEvent event) throws IOException {
    Stage ingresarStage = (Stage) btnCancelar.getScene().getWindow();
    ingresarStage.close();
    Stage unirseAPartidaStage = new Stage();
    Parent unirseAPartidaRoot = FXMLLoader.load(getClass().getResource("/gui/UnirseAPartida.fxml"),
        ResourceBundle.getBundle("idiomas.UnirseAPartida", Locale.getDefault()));
    Scene unirseAPartidaScene = new Scene(unirseAPartidaRoot);
    unirseAPartidaStage.setScene(unirseAPartidaScene);
    unirseAPartidaStage.show();
  }
  
}
