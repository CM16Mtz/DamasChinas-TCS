package gui;

import entidades.Jugador;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import otros.Context;

/**
 * FXML Controller de la GUI CambiarIdioma
 * @author Jatniel Martínez
 */
public class CambiarIdiomaController implements Initializable {
  
  @FXML private Label label;
  @FXML private RadioButton rdbEspanol;
  @FXML private RadioButton rdbIngles;
  @FXML private Button btnEstablecer;
  Jugador jugador = new Jugador();
  
  private ToggleGroup botones;

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    jugador = Context.getInstance().getJugador();
    botones = new ToggleGroup();
    rdbEspanol.setToggleGroup(botones);
    rdbIngles.setToggleGroup(botones);
  }
  
  @FXML
  void establecerIdioma(ActionEvent event) throws IOException {
    botones.selectedToggleProperty().addListener(
        (ObservableValue<? extends Toggle> ov, Toggle old_toggle, Toggle new_toggle) -> {
      if (botones.getSelectedToggle() != null) {
        if (rdbEspanol.isSelected()) {
          Locale.setDefault(new Locale("es"));
        } else if (rdbIngles.isSelected()) {
          Locale.setDefault(Locale.ENGLISH);
        }
      }
    });
    if (jugador.getTipo().equals("Registrado")) {
      Stage cambiarIdiomaStage = (Stage) btnEstablecer.getScene().getWindow();
      cambiarIdiomaStage.close();
      Stage menuRegistradoStage = new Stage();
      Parent menuRegistradoRoot = FXMLLoader.load(getClass().getResource("/gui/MenuRegistrado.fxml"),
          ResourceBundle.getBundle("idiomas.MenuRegistrado", Locale.getDefault()));
      Scene menuRegistradoScene = new Scene(menuRegistradoRoot);
      menuRegistradoStage.setScene(menuRegistradoScene);
      menuRegistradoStage.show();
    } else if (jugador.getTipo().equals("Invitado")) {
      Stage cambiarIdiomaStage = (Stage) btnEstablecer.getScene().getWindow();
      cambiarIdiomaStage.close();
      Stage menuInvitadoStage = new Stage();
      Parent menuInvitadoRoot = FXMLLoader.load(getClass().getResource("/gui/MenuInvitado.fxml"),
          ResourceBundle.getBundle("idiomas.MenuInvitado", Locale.getDefault()));
      Scene menuInvitadoScene = new Scene(menuInvitadoRoot);
      menuInvitadoStage.setScene(menuInvitadoScene);
      menuInvitadoStage.show();
    }
  }
  
}
