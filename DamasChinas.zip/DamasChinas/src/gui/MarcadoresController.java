package gui;

import entidades.Jugador;
import entidades.Marcadores;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import otros.Context;

/**
 * FXML Controller de la GUI Marcadores
 * @author Jatniel Martínez
 */
public class MarcadoresController implements Initializable {
  
  @FXML private TableView<Marcadores> tblMarcadores;
  @FXML private TableColumn<Jugador, String> colJugador;
  @FXML private TableColumn<Marcadores, Integer> colPuntuacion;
  @FXML private Button btnRegresar;
  Jugador jugador = new Jugador();

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    jugador = Context.getInstance().getJugador();
    colJugador.setCellValueFactory(new PropertyValueFactory<>("nombreJugador"));
    colPuntuacion.setCellValueFactory(new PropertyValueFactory<>("puntuacion"));
  }
  
  @FXML
  void regresar(ActionEvent event) throws IOException {
    Stage marcadoresStage = (Stage) btnRegresar.getScene().getWindow();
    marcadoresStage.close();
    if (jugador.getTipo().equals("Registrado")) {
      Stage menuRegistradoStage = new Stage();
      Parent menuRegistradoRoot = FXMLLoader.load(
          getClass().getResource("/gui/MenuRegistrado.fxml"),
          ResourceBundle.getBundle("idiomas.MenuRegistrado", Locale.getDefault()));
      Scene menuRegistradoScene = new Scene(menuRegistradoRoot);
      menuRegistradoStage.setScene(menuRegistradoScene);
      menuRegistradoStage.show();
    } else if (jugador.getTipo().equals("Invitado")) {
      Stage menuInvitadoStage = new Stage();
      Parent menuInvitadoRoot = FXMLLoader.load(
          getClass().getResource("/gui/MenuInvitado.fxml"),
          ResourceBundle.getBundle("idiomas.MenuInvitado", Locale.getDefault()));
      Scene menuInvitadoScene = new Scene(menuInvitadoRoot);
      menuInvitadoStage.setScene(menuInvitadoScene);
      menuInvitadoStage.show();
    }
  }
  
}
