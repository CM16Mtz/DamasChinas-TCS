package gui;

import entidades.Jugador;
import entidades.Partida;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import otros.Context;

/**
 * FXML Controller de la clase UnirseAPartida
 * @author Jatniel Martínez
 */
public class UnirseAPartidaController implements Initializable {
  
  @FXML private TableView<Partida> tblPartidas;
  @FXML private TableColumn<Partida, String> colPartida;
  @FXML private TableColumn<Jugador, String> colCreador;
  @FXML private Button btnIngresar;
  @FXML private Button btnCancelar;
  Jugador jugador = new Jugador();

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    jugador = Context.getInstance().getJugador();
    colPartida.setCellValueFactory(new PropertyValueFactory<>("nombrePartida"));
    colCreador.setCellValueFactory(new PropertyValueFactory<>("nombreJugador"));
  }
  
  @FXML
  void accederAPartida(ActionEvent event) throws IOException {
    Partida partida = tblPartidas.getSelectionModel().getSelectedItem();
    if (jugador.getTipo().equals("Registrado")) {
      Context.getInstance().setJugador(jugador);
      Context.getInstance().setPartida(partida);
      Stage unirseAPartidaStage = (Stage) btnIngresar.getScene().getWindow();
      unirseAPartidaStage.close();
      Stage seleccionarColorStage = new Stage();
      Parent seleccionarColorRoot = FXMLLoader.load(
          getClass().getResource("/gui/SeleccionarColor.fxml"),
          ResourceBundle.getBundle("idiomas.SeleccionarColor", Locale.getDefault()));
      Scene seleccionarColorScene = new Scene(seleccionarColorRoot);
      seleccionarColorStage.setScene(seleccionarColorScene);
      seleccionarColorStage.show();
    } else if (jugador.getTipo().equals("Invitado")) {
      Context.getInstance().setJugador(jugador);
      Context.getInstance().setPartida(partida);
      Stage unirseAPartidaStage = (Stage) btnIngresar.getScene().getWindow();
      unirseAPartidaStage.close();
      Stage ingresarAPartidaStage = new Stage();
      Parent ingresarAPartidaRoot = FXMLLoader.load(
          getClass().getResource("/gui/IngresarAPartida.fxml"),
          ResourceBundle.getBundle("idiomas.IngresarAPartida", Locale.getDefault()));
      Scene ingresarAPartidaScene = new Scene(ingresarAPartidaRoot);
      ingresarAPartidaStage.setScene(ingresarAPartidaScene);
      ingresarAPartidaStage.show();
    }
  }
  
  @FXML
  void cancelar(ActionEvent event) throws IOException {
    if (jugador.getTipo().equals("Registrado")) {
      Stage unirseAPartidaStage = (Stage) btnCancelar.getScene().getWindow();
      unirseAPartidaStage.close();
      Stage menuRegistradoStage = new Stage();
      Parent menuRegistradoRoot = FXMLLoader.load(
          getClass().getResource("/gui/MenuRegistrado.fxml"));
      Scene menuRegistradoScene = new Scene(menuRegistradoRoot);
      menuRegistradoStage.setScene(menuRegistradoScene);
      menuRegistradoStage.show();
    } else if (jugador.getTipo().equals("Invitado")) {
      Stage unirseAPartidaStage = (Stage) btnCancelar.getScene().getWindow();
      unirseAPartidaStage.close();
      Stage menuInvitadoStage = new Stage();
      Parent menuInvitadoRoot = FXMLLoader.load(
          getClass().getResource("/gui/MenuInvitado.fxml"));
      Scene menuInvitadoScene = new Scene(menuInvitadoRoot);
      menuInvitadoStage.setScene(menuInvitadoScene);
      menuInvitadoStage.show();
    }
  }
  
}
