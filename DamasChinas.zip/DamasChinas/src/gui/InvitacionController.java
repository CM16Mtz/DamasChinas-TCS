package gui;

import entidades.Partida;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import otros.Context;

/**
 * FXML Controller de la GUI Invitacion
 * @author Jatniel Martínez
 */
public class InvitacionController implements Initializable {
  
  @FXML private Label lblPregunta;
  @FXML private Label lblCorreo;
  @FXML private TextField txfCorreo;
  @FXML private Label lblAlerta;
  @FXML private Label lblClave;
  @FXML private PasswordField pwfClave;
  @FXML private Button btnInvitar;
  @FXML private Button btnCancelar;
  Partida partida = new Partida();

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    partida = Context.getInstance().getPartida();
  }
  
  @FXML
  void enviarInvitacion(ActionEvent event) throws IOException {
    String correo = txfCorreo.getText();
    String clave = pwfClave.getText();
    if (!correo.isEmpty() && !clave.isEmpty()) {
      Alert info = new Alert(AlertType.INFORMATION);
      info.setTitle("Enviada");
      info.setHeaderText(null);
      info.setContentText("Tu invitación ha sido enviada al correo que ingresaste");
      info.showAndWait();
      enviarCorreo(correo);
      Stage invitacionStage = (Stage) btnInvitar.getScene().getWindow();
      invitacionStage.close();
      Context.getInstance().setPartida(partida);
      Stage seleccionarColorStage = new Stage();
      Parent seleccionarColorRoot = FXMLLoader.load(
          getClass().getResource("/gui/SeleccionarColor.fxml"),
          ResourceBundle.getBundle("idiomas.SeleccionarColor", Locale.getDefault()));
      Scene seleccionarColorScene = new Scene(seleccionarColorRoot);
      seleccionarColorStage.setScene(seleccionarColorScene);
      seleccionarColorStage.show();
    } else {
      Alert advertencia = new Alert(AlertType.WARNING);
      advertencia.setTitle("Datos nulos");
      advertencia.setHeaderText(null);
      advertencia.setContentText("No puedes enviar una invitación sin destinatario ni contraseña");
      advertencia.showAndWait();
    }
  }
  
  @FXML
  void cancelar(ActionEvent event) throws IOException {
    Stage invitacionStage = (Stage) btnInvitar.getScene().getWindow();
    invitacionStage.close();
    Stage crearPartidaStage = new Stage();
    Parent crearPartidaRoot = FXMLLoader.load(getClass().getResource("/gui/CrearPartida.fxml"),
        ResourceBundle.getBundle("idiomas.CrearPartida", Locale.getDefault()));
    Scene crearPartidaScene = new Scene(crearPartidaRoot);
    crearPartidaStage.setScene(crearPartidaScene);
    crearPartidaStage.show();
  }
  
  public void enviarCorreo(String destinatario) {
    Properties p = new Properties();
    p.put("mail.smtp.host", "smtp.gmail.com");    //Host de Google
    p.put("mail.smtp.starttls.enable", "true");    //Conexión segura al servidor
    p.put("mail.smtp.port", "587");    //Puerto SMTP seguro de Google
    p.put("mail.smtp.auth", "true");    //Habilitar autenticación de credenciales
    Session s = Session.getInstance(p, new Authenticator() {
      @Override
      protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication("jatnielmtz@gmail.com", "CleoViridia");
      }
    });
    try {
      Message mensaje = new MimeMessage(s);
      mensaje.setFrom(new InternetAddress("jatnielmtz@gmail.com"));
      //mensaje.setFrom(new InternetAddress((String)p.get("mail.smtp.mail.sender")));
      mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
      mensaje.setSubject("Registro a DamasChinas - JavaFX");
      mensaje.setText(
          "Este es un mensaje para verificar que usted se registró en el juego de damas chinas");
      Transport.send(mensaje);
    } catch (MessagingException ex) {
      Alert error = new Alert(AlertType.ERROR);
      error.setTitle("Error de envío");
      error.setHeaderText(null);
      error.setContentText("Se produjo un error al enviarte un correo de verificación");
      error.showAndWait();
      ex.printStackTrace();
    }
  }
  
}
