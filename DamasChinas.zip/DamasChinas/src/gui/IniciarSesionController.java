package gui;

import controladoresjpa.JugadorJpaController;
import entidades.Jugador;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.persistence.Persistence;
import otros.Context;

/**
 * FXML Controller de la GUI IniciarSesion
 * @author Jatniel Martínez
 */
public class IniciarSesionController implements Initializable {
  
  @FXML private Label lblUsuario;
  @FXML private Label lblContrasena;
  @FXML private TextField txfUsuario;
  @FXML private PasswordField pwfContrasena;
  @FXML private Button btnIngresar;
  @FXML private Button btnInvitado;
  @FXML private Button btnRegistrar;

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    // TODO
  }
  
  @FXML
  void ingresarComoRegistrado(ActionEvent event) throws IOException {
    String nombreUsuario = txfUsuario.getText();
    String contrasena = pwfContrasena.getText();
    Jugador jugador = new Jugador();
    jugador.setNombreJugador(nombreUsuario);
    jugador.setContrasena(contrasena);
    JugadorJpaController controller =
        new JugadorJpaController(Persistence.createEntityManagerFactory("DamasChinasPU"));
    Jugador auxiliar = controller.validarJugador(jugador);
    if (auxiliar != null) {
      Context.getInstance().setJugador(auxiliar);
      Parent menuRegistradoRoot = FXMLLoader.load(getClass().getResource("/gui/MenuRegistrado.fxml"),
          ResourceBundle.getBundle("idiomas.MenuRegistrado", Locale.getDefault()));
      Scene menuRegistradoScene = new Scene(menuRegistradoRoot);
      Stage menuRegistradoStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
      menuRegistradoStage.setScene(menuRegistradoScene);
      menuRegistradoStage.show();
    } else {
      Alert alertDatosInvalidos = new Alert(AlertType.ERROR);
      if (Locale.getDefault() == Locale.ENGLISH) {
        alertDatosInvalidos.setTitle("Player not found");
        alertDatosInvalidos.setHeaderText("The inserts do not match with our registries");
        alertDatosInvalidos.setContentText("Please, insert the correct information");
        alertDatosInvalidos.showAndWait();
      } else if (Locale.getDefault() == new Locale("es")) {
        alertDatosInvalidos.setTitle("Jugador no encontrado");
        alertDatosInvalidos.setHeaderText("Los datos ingresados no coinciden con nuestros registros");
        alertDatosInvalidos.setContentText("Por favor, ingrese la información correcta");
        alertDatosInvalidos.showAndWait();
      }
    }
  }
  
  @FXML
  void ingresarComoInvitado(ActionEvent event) throws IOException {
    String nombreJugador = "Invitado" + Double.toString(Math.random());
    String correo = "Sin correo registrado";
    String tipo = "Invitado";
    Jugador invitado = new Jugador(0, nombreJugador, correo, tipo);
    JugadorJpaController controller =
        new JugadorJpaController(Persistence.createEntityManagerFactory("DamasChinasPU"));
    controller.create(invitado);
    Context.getInstance().setJugador(invitado);
    Stage iniciarSesionStage = (Stage) btnInvitado.getScene().getWindow();
    iniciarSesionStage.close();
    Stage menuInvitadoStage = new Stage();
    Parent menuInvitadoRoot = FXMLLoader.load(getClass().getResource("/gui/MenuInvitado.fxml"),
        ResourceBundle.getBundle("idiomas.MenuInvitado", Locale.getDefault()));
    Scene menuInvitadoScene = new Scene(menuInvitadoRoot);
    menuInvitadoStage.setScene(menuInvitadoScene);
    menuInvitadoStage.show();
  }
  
  @FXML
  void registrarse(ActionEvent event) throws IOException {
    Stage iniciarSesionStage = (Stage) btnRegistrar.getScene().getWindow();
    iniciarSesionStage.close();
    Stage registrarseStage = new Stage();
    Parent registrarseRoot = FXMLLoader.load(getClass().getResource("/gui/Registrarse.fxml"),
        ResourceBundle.getBundle("idiomas.Registrarse", Locale.getDefault()));
    Scene registrarseScene = new Scene(registrarseRoot);
    registrarseStage.setScene(registrarseScene);
    registrarseStage.show();
  }
  
}
