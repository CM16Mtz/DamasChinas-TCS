package gui;

import entidades.Estadisticas;
import entidades.Jugador;
import entidades.Marcadores;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import otros.Context;

/**
 * FXML Controller de la GUI Estadisticas
 * @author Jatniel Martínez
 */
public class EstadisticasController implements Initializable {
  
  @FXML private Label lblJugadas;
  @FXML private Label lblGanadas;
  @FXML private Label lblPorcentaje;
  @FXML private Label lblFechaRegistro;
  @FXML private Label lblPuntuacionMaxima;
  @FXML private Label numJugadas;    //Texto que almacena el número de partidas jugadas
  @FXML private Label numGanadas;    //Texto que almacena el número de partidas ganadas
  @FXML private Label porcentaje;    //Texto que almacena el promedio de las ganadas entre las jugadas
  @FXML private Label fechaRegistro;    //Texto que almacena en formato DD/MM/AAAA la fecha de registro del usuario
  @FXML private Label puntuacion;    //Texto que almacena la puntuación más alta en una partida
  @FXML private Button btnRegresar;
  Jugador jugador = new Jugador();

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    jugador = Context.getInstance().getJugador();
    List<Estadisticas> estadisticas = jugador.getEstadisticasList();
    List<Marcadores> marcadores = jugador.getMarcadoresList();
    Estadisticas estadistica = estadisticas.get(0);
    int puntuacionAlta = 0;
    for (int i = 0; i < marcadores.size(); i++) {
      Marcadores marcador = marcadores.get(i);
      int puntuacionAuxiliar = marcador.getPuntuacion();
      if (puntuacionAlta < puntuacionAuxiliar) {
        puntuacionAlta = puntuacionAuxiliar;
      }
    }
    int jugadas = estadistica.getPartidasJugadas();
    int ganadas = estadistica.getPartidasGanadas();
    double porcentajeDouble = ganadas / jugadas * 100;
    Date fecha = estadistica.getFechaRegistro();
    numJugadas.setText(Integer.toString(jugadas));
    numGanadas.setText(Integer.toString(ganadas));
    porcentaje.setText(Double.toString(porcentajeDouble));
    fechaRegistro.setText(fecha.toString());
    puntuacion.setText(Integer.toString(puntuacionAlta));
  }
  
  @FXML
  void regresar(ActionEvent event) throws IOException {
    if (jugador.getTipo().equals("Registrado")) {
      Stage cambiarIdiomaStage = (Stage) btnRegresar.getScene().getWindow();
      cambiarIdiomaStage.close();
      Stage menuRegistradoStage = new Stage();
      Parent menuRegistradoRoot = FXMLLoader.load(getClass().getResource("/gui/MenuRegistrado.fxml"),
          ResourceBundle.getBundle("idiomas.MenuRegistrado", Locale.getDefault()));
      Scene menuRegistradoScene = new Scene(menuRegistradoRoot);
      menuRegistradoStage.setScene(menuRegistradoScene);
      menuRegistradoStage.show();
    } else if (jugador.getTipo().equals("Invitado")) {
      Stage cambiarIdiomaStage = (Stage) btnRegresar.getScene().getWindow();
      cambiarIdiomaStage.close();
      Stage menuInvitadoStage = new Stage();
      Parent menuInvitadoRoot = FXMLLoader.load(getClass().getResource("/gui/MenuInvitado.fxml"),
          ResourceBundle.getBundle("idiomas.MenuInvitado", Locale.getDefault()));
      Scene menuInvitadoScene = new Scene(menuInvitadoRoot);
      menuInvitadoStage.setScene(menuInvitadoScene);
      menuInvitadoStage.show();
    }
  }
  
}
