/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import entidades.Jugador;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import otros.Context;

/**
 * FXML Controller class
 *
 * @author HP
 */
public class MenuRegistradoController implements Initializable {
  
  @FXML private Label lblBienvenido;
  @FXML private Button btnCrear;
  @FXML private Button btnUnirse;
  @FXML private Button btnMarcadores;
  @FXML private Button btnEstadisticas;
  @FXML private Button btnIdioma;
  @FXML private Button btnSalir;
  Jugador registrado = new Jugador();

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    registrado = Context.getInstance().getJugador();
    if (Locale.getDefault() == Locale.ENGLISH) {
      lblBienvenido.setText("Welcome " + registrado.getNombreJugador());
    } else {
      lblBienvenido.setText("Bienvenido " + registrado.getNombreJugador());
    }
  }
  
  @FXML
  void crearPartida(ActionEvent event) throws IOException {
    Stage menuRegistradoStage = (Stage) btnCrear.getScene().getWindow();
    menuRegistradoStage.hide();
    Stage crearPartidaStage = new Stage();
    Parent crearPartidaRoot = FXMLLoader.load(getClass().getResource("/gui/CrearPartida.fxml"),
        ResourceBundle.getBundle("idiomas.CrearPartida", Locale.getDefault()));
    Scene crearPartidaScene = new Scene(crearPartidaRoot);
    crearPartidaStage.setScene(crearPartidaScene);
    crearPartidaStage.show();
  }
  
  @FXML
  void unirseAPartida(ActionEvent event) throws IOException {
    Stage menuRegistradoStage = (Stage) btnUnirse.getScene().getWindow();
    menuRegistradoStage.hide();
    Stage unirseAPartidaStage = new Stage();
    Parent unirseAPartidaRoot = FXMLLoader.load(getClass().getResource("/gui/UnirseAPartida.fxml"),
        ResourceBundle.getBundle("idiomas.UnirseAPartida", Locale.getDefault()));
    Scene unirseAPartidaScene = new Scene(unirseAPartidaRoot);
    unirseAPartidaStage.setScene(unirseAPartidaScene);
    unirseAPartidaStage.show();
  }
  
  @FXML
  void consultarMarcadores(ActionEvent event) throws IOException {
    Stage menuRegistradoStage = (Stage) btnMarcadores.getScene().getWindow();
    menuRegistradoStage.hide();
    Stage marcadoresStage = new Stage();
    Parent marcadoresRoot = FXMLLoader.load(getClass().getResource("/gui/Marcadores.fxml"),
        ResourceBundle.getBundle("idiomas.Marcadores", Locale.getDefault()));
    Scene marcadoresScene = new Scene(marcadoresRoot);
    marcadoresStage.setScene(marcadoresScene);
    marcadoresStage.show();
  }
  
  @FXML
  void consultarEstadisticas(ActionEvent event) throws IOException {
    Stage menuRegistradoStage = (Stage) btnEstadisticas.getScene().getWindow();
    menuRegistradoStage.hide();
    Stage estadisticasStage = new Stage();
    Parent estadisticasRoot = FXMLLoader.load(getClass().getResource("/gui/Estadisticas.fxml"),
        ResourceBundle.getBundle("idiomas.Estadisticas", Locale.getDefault()));
    Scene estadisticasScene = new Scene(estadisticasRoot);
    estadisticasStage.setScene(estadisticasScene);
    estadisticasStage.show();
  }
  
  @FXML
  void cambiarIdioma(ActionEvent event) throws IOException {
    Stage menuRegistradoStage = (Stage) btnIdioma.getScene().getWindow();
    menuRegistradoStage.hide();
    Stage cambiarIdiomaStage = new Stage();
    Parent cambiarIdiomaRoot = FXMLLoader.load(getClass().getResource("/gui/CambiarIdioma.fxml"),
        ResourceBundle.getBundle("idiomas.CambiarIdioma", Locale.getDefault()));
    Scene cambiarIdiomaScene = new Scene(cambiarIdiomaRoot);
    cambiarIdiomaStage.setScene(cambiarIdiomaScene);
    cambiarIdiomaStage.show();
  }
  
  @FXML
  void cerrarSesion(ActionEvent event) throws IOException {
    Stage menuRegistradoStage = (Stage) btnSalir.getScene().getWindow();
    menuRegistradoStage.close();
    Stage iniciarSesionStage = new Stage();
    Parent iniciarSesionRoot = FXMLLoader.load(getClass().getResource("/gui/IniciarSesion.fxml"),
        ResourceBundle.getBundle("idiomas.IniciarSesion", Locale.getDefault()));
    Scene iniciarSesionScene = new Scene(iniciarSesionRoot);
    iniciarSesionStage.setScene(iniciarSesionScene);
    iniciarSesionStage.show();
  }
  
}
