package gui;

import controladoresjpa.PartidaJpaController;
import entidades.Partida;
import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.persistence.Persistence;
import otros.Context;

/**
 * FXML Controller de la gui CrearPartida
 * @author Jatniel Martínez
 */
public class CrearPartidaController implements Initializable {
  
  @FXML private Label lblNombre;
  @FXML private Label lblNumero;
  @FXML private TextField txfNombre;
  @FXML private ComboBox cmbNumero;
  @FXML private Button btnCrear;
  @FXML private Button btnInvitar;
  @FXML private Button btnRegresar;

  /**
   * Initializes the controller class.
   */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
    ObservableList<Integer> jugadores = FXCollections.observableArrayList(1, 2, 3, 4, 5, 6);
    cmbNumero.setItems(jugadores);
  }
  
  @FXML
  void crearPartida(ActionEvent event) throws IOException {
    String nombrePartida = txfNombre.getText();
    Integer numJugadores = (Integer) cmbNumero.getValue();
    if (!nombrePartida.isEmpty() && numJugadores != null) {
      Partida partida = new Partida(0, nombrePartida, numJugadores);
      PartidaJpaController controller =
          new PartidaJpaController(Persistence.createEntityManagerFactory("DamasChinasPU"));
      controller.create(partida);
      Stage menuCrearStage = (Stage) btnCrear.getScene().getWindow();
      menuCrearStage.close();
      Alert espera = new Alert(AlertType.WARNING);
      espera.setTitle("Esperando");
      espera.setHeaderText(null);
      espera.setContentText("Espera a que los otros jugadores se conecten");
      espera.showAndWait();
      Context.getInstance().setPartida(partida);
      Stage seleccionarColorStage = new Stage();
      Parent seleccionarColorRoot = FXMLLoader.load(
          getClass().getResource("/gui/SeleccionarColor.fxml"),
          ResourceBundle.getBundle("idiomas.SeleccionarColor", Locale.getDefault()));
      Scene seleccionarColorScene = new Scene(seleccionarColorRoot);
      seleccionarColorStage.setScene(seleccionarColorScene);
      seleccionarColorStage.show();
    }
  }
  
  @FXML
  void invitarJugadores(ActionEvent event) throws IOException {
    String nombrePartida = txfNombre.getText();
    Integer numJugadores = (Integer) cmbNumero.getValue();
    if (!nombrePartida.isEmpty() && numJugadores != null) {
      Partida partida = new Partida(0, nombrePartida, numJugadores);
      PartidaJpaController controller =
          new PartidaJpaController(Persistence.createEntityManagerFactory("DamasChinasPU"));
      controller.create(partida);
      Context.getInstance().setPartida(partida);
      Stage menuCrearStage = (Stage) btnInvitar.getScene().getWindow();
      menuCrearStage.close();
      Stage invitacionStage = new Stage();
      Parent invitacionRoot = FXMLLoader.load(getClass().getResource("/gui/Invitacion.fxml"),
          ResourceBundle.getBundle("idiomas.Invitacion", Locale.getDefault()));
      Scene invitacionScene = new Scene(invitacionRoot);
      invitacionStage.setScene(invitacionScene);
      invitacionStage.show();
    }
  }
  
  @FXML
  void regresar(ActionEvent event) throws IOException {
      Stage menuCrearStage = (Stage) btnRegresar.getScene().getWindow();
      menuCrearStage.close();
      Stage menuRegistradoStage = new Stage();
      Parent menuRegistradoRoot = FXMLLoader.load(getClass().getResource("/gui/MenuRegistrado.fxml"),
          ResourceBundle.getBundle("idiomas.MenuRegistrado", Locale.getDefault()));
      Scene menuRegistradoScene = new Scene(menuRegistradoRoot);
      menuRegistradoStage.setScene(menuRegistradoScene);
      menuRegistradoStage.show();
  }
  
}
