/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladoresjpa;

import controladoresjpa.exceptions.IllegalOrphanException;
import controladoresjpa.exceptions.NonexistentEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entidades.Chat;
import java.util.ArrayList;
import java.util.List;
import entidades.Juego;
import entidades.Partida;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author HP
 */
public class PartidaJpaController implements Serializable {

  public PartidaJpaController(EntityManagerFactory emf) {
    this.emf = emf;
  }
  private EntityManagerFactory emf = null;

  public EntityManager getEntityManager() {
    return emf.createEntityManager();
  }

  public void create(Partida partida) {
    if (partida.getChatList() == null) {
      partida.setChatList(new ArrayList<Chat>());
    }
    if (partida.getJuegoList() == null) {
      partida.setJuegoList(new ArrayList<Juego>());
    }
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      List<Chat> attachedChatList = new ArrayList<Chat>();
      for (Chat chatListChatToAttach : partida.getChatList()) {
        chatListChatToAttach = em.getReference(chatListChatToAttach.getClass(), chatListChatToAttach.getIdChat());
        attachedChatList.add(chatListChatToAttach);
      }
      partida.setChatList(attachedChatList);
      List<Juego> attachedJuegoList = new ArrayList<Juego>();
      for (Juego juegoListJuegoToAttach : partida.getJuegoList()) {
        juegoListJuegoToAttach = em.getReference(juegoListJuegoToAttach.getClass(), juegoListJuegoToAttach.getJuegoPK());
        attachedJuegoList.add(juegoListJuegoToAttach);
      }
      partida.setJuegoList(attachedJuegoList);
      em.persist(partida);
      for (Chat chatListChat : partida.getChatList()) {
        Partida oldPartidaidPartidaOfChatListChat = chatListChat.getPartidaidPartida();
        chatListChat.setPartidaidPartida(partida);
        chatListChat = em.merge(chatListChat);
        if (oldPartidaidPartidaOfChatListChat != null) {
          oldPartidaidPartidaOfChatListChat.getChatList().remove(chatListChat);
          oldPartidaidPartidaOfChatListChat = em.merge(oldPartidaidPartidaOfChatListChat);
        }
      }
      for (Juego juegoListJuego : partida.getJuegoList()) {
        Partida oldPartidaOfJuegoListJuego = juegoListJuego.getPartida();
        juegoListJuego.setPartida(partida);
        juegoListJuego = em.merge(juegoListJuego);
        if (oldPartidaOfJuegoListJuego != null) {
          oldPartidaOfJuegoListJuego.getJuegoList().remove(juegoListJuego);
          oldPartidaOfJuegoListJuego = em.merge(oldPartidaOfJuegoListJuego);
        }
      }
      em.getTransaction().commit();
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void edit(Partida partida) throws IllegalOrphanException, NonexistentEntityException, Exception {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Partida persistentPartida = em.find(Partida.class, partida.getIdPartida());
      List<Chat> chatListOld = persistentPartida.getChatList();
      List<Chat> chatListNew = partida.getChatList();
      List<Juego> juegoListOld = persistentPartida.getJuegoList();
      List<Juego> juegoListNew = partida.getJuegoList();
      List<String> illegalOrphanMessages = null;
      for (Chat chatListOldChat : chatListOld) {
        if (!chatListNew.contains(chatListOldChat)) {
          if (illegalOrphanMessages == null) {
            illegalOrphanMessages = new ArrayList<String>();
          }
          illegalOrphanMessages.add("You must retain Chat " + chatListOldChat + " since its partidaidPartida field is not nullable.");
        }
      }
      for (Juego juegoListOldJuego : juegoListOld) {
        if (!juegoListNew.contains(juegoListOldJuego)) {
          if (illegalOrphanMessages == null) {
            illegalOrphanMessages = new ArrayList<String>();
          }
          illegalOrphanMessages.add("You must retain Juego " + juegoListOldJuego + " since its partida field is not nullable.");
        }
      }
      if (illegalOrphanMessages != null) {
        throw new IllegalOrphanException(illegalOrphanMessages);
      }
      List<Chat> attachedChatListNew = new ArrayList<Chat>();
      for (Chat chatListNewChatToAttach : chatListNew) {
        chatListNewChatToAttach = em.getReference(chatListNewChatToAttach.getClass(), chatListNewChatToAttach.getIdChat());
        attachedChatListNew.add(chatListNewChatToAttach);
      }
      chatListNew = attachedChatListNew;
      partida.setChatList(chatListNew);
      List<Juego> attachedJuegoListNew = new ArrayList<Juego>();
      for (Juego juegoListNewJuegoToAttach : juegoListNew) {
        juegoListNewJuegoToAttach = em.getReference(juegoListNewJuegoToAttach.getClass(), juegoListNewJuegoToAttach.getJuegoPK());
        attachedJuegoListNew.add(juegoListNewJuegoToAttach);
      }
      juegoListNew = attachedJuegoListNew;
      partida.setJuegoList(juegoListNew);
      partida = em.merge(partida);
      for (Chat chatListNewChat : chatListNew) {
        if (!chatListOld.contains(chatListNewChat)) {
          Partida oldPartidaidPartidaOfChatListNewChat = chatListNewChat.getPartidaidPartida();
          chatListNewChat.setPartidaidPartida(partida);
          chatListNewChat = em.merge(chatListNewChat);
          if (oldPartidaidPartidaOfChatListNewChat != null && !oldPartidaidPartidaOfChatListNewChat.equals(partida)) {
            oldPartidaidPartidaOfChatListNewChat.getChatList().remove(chatListNewChat);
            oldPartidaidPartidaOfChatListNewChat = em.merge(oldPartidaidPartidaOfChatListNewChat);
          }
        }
      }
      for (Juego juegoListNewJuego : juegoListNew) {
        if (!juegoListOld.contains(juegoListNewJuego)) {
          Partida oldPartidaOfJuegoListNewJuego = juegoListNewJuego.getPartida();
          juegoListNewJuego.setPartida(partida);
          juegoListNewJuego = em.merge(juegoListNewJuego);
          if (oldPartidaOfJuegoListNewJuego != null && !oldPartidaOfJuegoListNewJuego.equals(partida)) {
            oldPartidaOfJuegoListNewJuego.getJuegoList().remove(juegoListNewJuego);
            oldPartidaOfJuegoListNewJuego = em.merge(oldPartidaOfJuegoListNewJuego);
          }
        }
      }
      em.getTransaction().commit();
    } catch (Exception ex) {
      String msg = ex.getLocalizedMessage();
      if (msg == null || msg.length() == 0) {
        Integer id = partida.getIdPartida();
        if (findPartida(id) == null) {
          throw new NonexistentEntityException("The partida with id " + id + " no longer exists.");
        }
      }
      throw ex;
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Partida partida;
      try {
        partida = em.getReference(Partida.class, id);
        partida.getIdPartida();
      } catch (EntityNotFoundException enfe) {
        throw new NonexistentEntityException("The partida with id " + id + " no longer exists.", enfe);
      }
      List<String> illegalOrphanMessages = null;
      List<Chat> chatListOrphanCheck = partida.getChatList();
      for (Chat chatListOrphanCheckChat : chatListOrphanCheck) {
        if (illegalOrphanMessages == null) {
          illegalOrphanMessages = new ArrayList<String>();
        }
        illegalOrphanMessages.add("This Partida (" + partida + ") cannot be destroyed since the Chat " + chatListOrphanCheckChat + " in its chatList field has a non-nullable partidaidPartida field.");
      }
      List<Juego> juegoListOrphanCheck = partida.getJuegoList();
      for (Juego juegoListOrphanCheckJuego : juegoListOrphanCheck) {
        if (illegalOrphanMessages == null) {
          illegalOrphanMessages = new ArrayList<String>();
        }
        illegalOrphanMessages.add("This Partida (" + partida + ") cannot be destroyed since the Juego " + juegoListOrphanCheckJuego + " in its juegoList field has a non-nullable partida field.");
      }
      if (illegalOrphanMessages != null) {
        throw new IllegalOrphanException(illegalOrphanMessages);
      }
      em.remove(partida);
      em.getTransaction().commit();
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public List<Partida> findPartidaEntities() {
    return findPartidaEntities(true, -1, -1);
  }

  public List<Partida> findPartidaEntities(int maxResults, int firstResult) {
    return findPartidaEntities(false, maxResults, firstResult);
  }

  private List<Partida> findPartidaEntities(boolean all, int maxResults, int firstResult) {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      cq.select(cq.from(Partida.class));
      Query q = em.createQuery(cq);
      if (!all) {
        q.setMaxResults(maxResults);
        q.setFirstResult(firstResult);
      }
      return q.getResultList();
    } finally {
      em.close();
    }
  }

  public Partida findPartida(Integer id) {
    EntityManager em = getEntityManager();
    try {
      return em.find(Partida.class, id);
    } finally {
      em.close();
    }
  }

  public int getPartidaCount() {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      Root<Partida> rt = cq.from(Partida.class);
      cq.select(em.getCriteriaBuilder().count(rt));
      Query q = em.createQuery(cq);
      return ((Long) q.getSingleResult()).intValue();
    } finally {
      em.close();
    }
  }
  
  public Partida validarContrasena(Partida partida) {
    EntityManager em = getEntityManager();
    Partida auxiliar = 
        (Partida) em.createQuery("SELECT p FROM Partida p WHERE p.contrasena = :contrasena")
        .setParameter("contrasena", partida.getContrasena()).getSingleResult();
    return auxiliar;
  }
  
}
