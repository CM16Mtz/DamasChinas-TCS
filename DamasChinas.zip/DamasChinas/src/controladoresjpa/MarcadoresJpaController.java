/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladoresjpa;

import controladoresjpa.exceptions.NonexistentEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entidades.Jugador;
import entidades.Marcadores;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author HP
 */
public class MarcadoresJpaController implements Serializable {

  public MarcadoresJpaController(EntityManagerFactory emf) {
    this.emf = emf;
  }
  private EntityManagerFactory emf = null;

  public EntityManager getEntityManager() {
    return emf.createEntityManager();
  }

  public void create(Marcadores marcadores) {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Jugador jugadoridJugador = marcadores.getJugadoridJugador();
      if (jugadoridJugador != null) {
        jugadoridJugador = em.getReference(jugadoridJugador.getClass(), jugadoridJugador.getIdJugador());
        marcadores.setJugadoridJugador(jugadoridJugador);
      }
      em.persist(marcadores);
      if (jugadoridJugador != null) {
        jugadoridJugador.getMarcadoresList().add(marcadores);
        jugadoridJugador = em.merge(jugadoridJugador);
      }
      em.getTransaction().commit();
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void edit(Marcadores marcadores) throws NonexistentEntityException, Exception {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Marcadores persistentMarcadores = em.find(Marcadores.class, marcadores.getIdMarcadores());
      Jugador jugadoridJugadorOld = persistentMarcadores.getJugadoridJugador();
      Jugador jugadoridJugadorNew = marcadores.getJugadoridJugador();
      if (jugadoridJugadorNew != null) {
        jugadoridJugadorNew = em.getReference(jugadoridJugadorNew.getClass(), jugadoridJugadorNew.getIdJugador());
        marcadores.setJugadoridJugador(jugadoridJugadorNew);
      }
      marcadores = em.merge(marcadores);
      if (jugadoridJugadorOld != null && !jugadoridJugadorOld.equals(jugadoridJugadorNew)) {
        jugadoridJugadorOld.getMarcadoresList().remove(marcadores);
        jugadoridJugadorOld = em.merge(jugadoridJugadorOld);
      }
      if (jugadoridJugadorNew != null && !jugadoridJugadorNew.equals(jugadoridJugadorOld)) {
        jugadoridJugadorNew.getMarcadoresList().add(marcadores);
        jugadoridJugadorNew = em.merge(jugadoridJugadorNew);
      }
      em.getTransaction().commit();
    } catch (Exception ex) {
      String msg = ex.getLocalizedMessage();
      if (msg == null || msg.length() == 0) {
        Integer id = marcadores.getIdMarcadores();
        if (findMarcadores(id) == null) {
          throw new NonexistentEntityException("The marcadores with id " + id + " no longer exists.");
        }
      }
      throw ex;
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void destroy(Integer id) throws NonexistentEntityException {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Marcadores marcadores;
      try {
        marcadores = em.getReference(Marcadores.class, id);
        marcadores.getIdMarcadores();
      } catch (EntityNotFoundException enfe) {
        throw new NonexistentEntityException("The marcadores with id " + id + " no longer exists.", enfe);
      }
      Jugador jugadoridJugador = marcadores.getJugadoridJugador();
      if (jugadoridJugador != null) {
        jugadoridJugador.getMarcadoresList().remove(marcadores);
        jugadoridJugador = em.merge(jugadoridJugador);
      }
      em.remove(marcadores);
      em.getTransaction().commit();
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public List<Marcadores> findMarcadoresEntities() {
    return findMarcadoresEntities(true, -1, -1);
  }

  public List<Marcadores> findMarcadoresEntities(int maxResults, int firstResult) {
    return findMarcadoresEntities(false, maxResults, firstResult);
  }

  private List<Marcadores> findMarcadoresEntities(boolean all, int maxResults, int firstResult) {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      cq.select(cq.from(Marcadores.class));
      Query q = em.createQuery(cq);
      if (!all) {
        q.setMaxResults(maxResults);
        q.setFirstResult(firstResult);
      }
      return q.getResultList();
    } finally {
      em.close();
    }
  }

  public Marcadores findMarcadores(Integer id) {
    EntityManager em = getEntityManager();
    try {
      return em.find(Marcadores.class, id);
    } finally {
      em.close();
    }
  }

  public int getMarcadoresCount() {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      Root<Marcadores> rt = cq.from(Marcadores.class);
      cq.select(em.getCriteriaBuilder().count(rt));
      Query q = em.createQuery(cq);
      return ((Long) q.getSingleResult()).intValue();
    } finally {
      em.close();
    }
  }
  
}
