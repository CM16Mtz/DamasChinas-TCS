/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladoresjpa;

import controladoresjpa.exceptions.NonexistentEntityException;
import entidades.Estadisticas;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entidades.Jugador;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author HP
 */
public class EstadisticasJpaController implements Serializable {

  public EstadisticasJpaController(EntityManagerFactory emf) {
    this.emf = emf;
  }
  private EntityManagerFactory emf = null;

  public EntityManager getEntityManager() {
    return emf.createEntityManager();
  }

  public void create(Estadisticas estadisticas) {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Jugador jugadoridJugador = estadisticas.getJugadoridJugador();
      if (jugadoridJugador != null) {
        jugadoridJugador = em.getReference(jugadoridJugador.getClass(), jugadoridJugador.getIdJugador());
        estadisticas.setJugadoridJugador(jugadoridJugador);
      }
      em.persist(estadisticas);
      if (jugadoridJugador != null) {
        jugadoridJugador.getEstadisticasList().add(estadisticas);
        jugadoridJugador = em.merge(jugadoridJugador);
      }
      em.getTransaction().commit();
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void edit(Estadisticas estadisticas) throws NonexistentEntityException, Exception {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Estadisticas persistentEstadisticas = em.find(Estadisticas.class, estadisticas.getIdEstadisticas());
      Jugador jugadoridJugadorOld = persistentEstadisticas.getJugadoridJugador();
      Jugador jugadoridJugadorNew = estadisticas.getJugadoridJugador();
      if (jugadoridJugadorNew != null) {
        jugadoridJugadorNew = em.getReference(jugadoridJugadorNew.getClass(), jugadoridJugadorNew.getIdJugador());
        estadisticas.setJugadoridJugador(jugadoridJugadorNew);
      }
      estadisticas = em.merge(estadisticas);
      if (jugadoridJugadorOld != null && !jugadoridJugadorOld.equals(jugadoridJugadorNew)) {
        jugadoridJugadorOld.getEstadisticasList().remove(estadisticas);
        jugadoridJugadorOld = em.merge(jugadoridJugadorOld);
      }
      if (jugadoridJugadorNew != null && !jugadoridJugadorNew.equals(jugadoridJugadorOld)) {
        jugadoridJugadorNew.getEstadisticasList().add(estadisticas);
        jugadoridJugadorNew = em.merge(jugadoridJugadorNew);
      }
      em.getTransaction().commit();
    } catch (Exception ex) {
      String msg = ex.getLocalizedMessage();
      if (msg == null || msg.length() == 0) {
        Integer id = estadisticas.getIdEstadisticas();
        if (findEstadisticas(id) == null) {
          throw new NonexistentEntityException("The estadisticas with id " + id + " no longer exists.");
        }
      }
      throw ex;
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void destroy(Integer id) throws NonexistentEntityException {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Estadisticas estadisticas;
      try {
        estadisticas = em.getReference(Estadisticas.class, id);
        estadisticas.getIdEstadisticas();
      } catch (EntityNotFoundException enfe) {
        throw new NonexistentEntityException("The estadisticas with id " + id + " no longer exists.", enfe);
      }
      Jugador jugadoridJugador = estadisticas.getJugadoridJugador();
      if (jugadoridJugador != null) {
        jugadoridJugador.getEstadisticasList().remove(estadisticas);
        jugadoridJugador = em.merge(jugadoridJugador);
      }
      em.remove(estadisticas);
      em.getTransaction().commit();
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public List<Estadisticas> findEstadisticasEntities() {
    return findEstadisticasEntities(true, -1, -1);
  }

  public List<Estadisticas> findEstadisticasEntities(int maxResults, int firstResult) {
    return findEstadisticasEntities(false, maxResults, firstResult);
  }

  private List<Estadisticas> findEstadisticasEntities(boolean all, int maxResults, int firstResult) {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      cq.select(cq.from(Estadisticas.class));
      Query q = em.createQuery(cq);
      if (!all) {
        q.setMaxResults(maxResults);
        q.setFirstResult(firstResult);
      }
      return q.getResultList();
    } finally {
      em.close();
    }
  }

  public Estadisticas findEstadisticas(Integer id) {
    EntityManager em = getEntityManager();
    try {
      return em.find(Estadisticas.class, id);
    } finally {
      em.close();
    }
  }

  public int getEstadisticasCount() {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      Root<Estadisticas> rt = cq.from(Estadisticas.class);
      cq.select(em.getCriteriaBuilder().count(rt));
      Query q = em.createQuery(cq);
      return ((Long) q.getSingleResult()).intValue();
    } finally {
      em.close();
    }
  }
  
}
