/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladoresjpa;

import controladoresjpa.exceptions.NonexistentEntityException;
import controladoresjpa.exceptions.PreexistingEntityException;
import entidades.Chat;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entidades.Jugador;
import entidades.Partida;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author HP
 */
public class ChatJpaController implements Serializable {

  public ChatJpaController(EntityManagerFactory emf) {
    this.emf = emf;
  }
  private EntityManagerFactory emf = null;

  public EntityManager getEntityManager() {
    return emf.createEntityManager();
  }

  public void create(Chat chat) throws PreexistingEntityException, Exception {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Jugador jugadoridJugador = chat.getJugadoridJugador();
      if (jugadoridJugador != null) {
        jugadoridJugador = em.getReference(jugadoridJugador.getClass(), jugadoridJugador.getIdJugador());
        chat.setJugadoridJugador(jugadoridJugador);
      }
      Partida partidaidPartida = chat.getPartidaidPartida();
      if (partidaidPartida != null) {
        partidaidPartida = em.getReference(partidaidPartida.getClass(), partidaidPartida.getIdPartida());
        chat.setPartidaidPartida(partidaidPartida);
      }
      em.persist(chat);
      if (jugadoridJugador != null) {
        jugadoridJugador.getChatList().add(chat);
        jugadoridJugador = em.merge(jugadoridJugador);
      }
      if (partidaidPartida != null) {
        partidaidPartida.getChatList().add(chat);
        partidaidPartida = em.merge(partidaidPartida);
      }
      em.getTransaction().commit();
    } catch (Exception ex) {
      if (findChat(chat.getIdChat()) != null) {
        throw new PreexistingEntityException("Chat " + chat + " already exists.", ex);
      }
      throw ex;
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void edit(Chat chat) throws NonexistentEntityException, Exception {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Chat persistentChat = em.find(Chat.class, chat.getIdChat());
      Jugador jugadoridJugadorOld = persistentChat.getJugadoridJugador();
      Jugador jugadoridJugadorNew = chat.getJugadoridJugador();
      Partida partidaidPartidaOld = persistentChat.getPartidaidPartida();
      Partida partidaidPartidaNew = chat.getPartidaidPartida();
      if (jugadoridJugadorNew != null) {
        jugadoridJugadorNew = em.getReference(jugadoridJugadorNew.getClass(), jugadoridJugadorNew.getIdJugador());
        chat.setJugadoridJugador(jugadoridJugadorNew);
      }
      if (partidaidPartidaNew != null) {
        partidaidPartidaNew = em.getReference(partidaidPartidaNew.getClass(), partidaidPartidaNew.getIdPartida());
        chat.setPartidaidPartida(partidaidPartidaNew);
      }
      chat = em.merge(chat);
      if (jugadoridJugadorOld != null && !jugadoridJugadorOld.equals(jugadoridJugadorNew)) {
        jugadoridJugadorOld.getChatList().remove(chat);
        jugadoridJugadorOld = em.merge(jugadoridJugadorOld);
      }
      if (jugadoridJugadorNew != null && !jugadoridJugadorNew.equals(jugadoridJugadorOld)) {
        jugadoridJugadorNew.getChatList().add(chat);
        jugadoridJugadorNew = em.merge(jugadoridJugadorNew);
      }
      if (partidaidPartidaOld != null && !partidaidPartidaOld.equals(partidaidPartidaNew)) {
        partidaidPartidaOld.getChatList().remove(chat);
        partidaidPartidaOld = em.merge(partidaidPartidaOld);
      }
      if (partidaidPartidaNew != null && !partidaidPartidaNew.equals(partidaidPartidaOld)) {
        partidaidPartidaNew.getChatList().add(chat);
        partidaidPartidaNew = em.merge(partidaidPartidaNew);
      }
      em.getTransaction().commit();
    } catch (Exception ex) {
      String msg = ex.getLocalizedMessage();
      if (msg == null || msg.length() == 0) {
        String id = chat.getIdChat();
        if (findChat(id) == null) {
          throw new NonexistentEntityException("The chat with id " + id + " no longer exists.");
        }
      }
      throw ex;
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void destroy(String id) throws NonexistentEntityException {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Chat chat;
      try {
        chat = em.getReference(Chat.class, id);
        chat.getIdChat();
      } catch (EntityNotFoundException enfe) {
        throw new NonexistentEntityException("The chat with id " + id + " no longer exists.", enfe);
      }
      Jugador jugadoridJugador = chat.getJugadoridJugador();
      if (jugadoridJugador != null) {
        jugadoridJugador.getChatList().remove(chat);
        jugadoridJugador = em.merge(jugadoridJugador);
      }
      Partida partidaidPartida = chat.getPartidaidPartida();
      if (partidaidPartida != null) {
        partidaidPartida.getChatList().remove(chat);
        partidaidPartida = em.merge(partidaidPartida);
      }
      em.remove(chat);
      em.getTransaction().commit();
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public List<Chat> findChatEntities() {
    return findChatEntities(true, -1, -1);
  }

  public List<Chat> findChatEntities(int maxResults, int firstResult) {
    return findChatEntities(false, maxResults, firstResult);
  }

  private List<Chat> findChatEntities(boolean all, int maxResults, int firstResult) {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      cq.select(cq.from(Chat.class));
      Query q = em.createQuery(cq);
      if (!all) {
        q.setMaxResults(maxResults);
        q.setFirstResult(firstResult);
      }
      return q.getResultList();
    } finally {
      em.close();
    }
  }

  public Chat findChat(String id) {
    EntityManager em = getEntityManager();
    try {
      return em.find(Chat.class, id);
    } finally {
      em.close();
    }
  }

  public int getChatCount() {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      Root<Chat> rt = cq.from(Chat.class);
      cq.select(em.getCriteriaBuilder().count(rt));
      Query q = em.createQuery(cq);
      return ((Long) q.getSingleResult()).intValue();
    } finally {
      em.close();
    }
  }
  
}
