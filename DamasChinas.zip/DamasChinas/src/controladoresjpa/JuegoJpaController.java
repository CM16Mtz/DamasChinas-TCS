/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladoresjpa;

import controladoresjpa.exceptions.NonexistentEntityException;
import controladoresjpa.exceptions.PreexistingEntityException;
import entidades.Juego;
import entidades.JuegoPK;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entidades.Jugador;
import entidades.Partida;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author HP
 */
public class JuegoJpaController implements Serializable {

  public JuegoJpaController(EntityManagerFactory emf) {
    this.emf = emf;
  }
  private EntityManagerFactory emf = null;

  public EntityManager getEntityManager() {
    return emf.createEntityManager();
  }

  public void create(Juego juego) throws PreexistingEntityException, Exception {
    if (juego.getJuegoPK() == null) {
      juego.setJuegoPK(new JuegoPK());
    }
    juego.getJuegoPK().setJugadoridJugador(juego.getJugador().getIdJugador());
    juego.getJuegoPK().setPartidaidPartida(juego.getPartida().getIdPartida());
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Jugador jugador = juego.getJugador();
      if (jugador != null) {
        jugador = em.getReference(jugador.getClass(), jugador.getIdJugador());
        juego.setJugador(jugador);
      }
      Partida partida = juego.getPartida();
      if (partida != null) {
        partida = em.getReference(partida.getClass(), partida.getIdPartida());
        juego.setPartida(partida);
      }
      em.persist(juego);
      if (jugador != null) {
        jugador.getJuegoList().add(juego);
        jugador = em.merge(jugador);
      }
      if (partida != null) {
        partida.getJuegoList().add(juego);
        partida = em.merge(partida);
      }
      em.getTransaction().commit();
    } catch (Exception ex) {
      if (findJuego(juego.getJuegoPK()) != null) {
        throw new PreexistingEntityException("Juego " + juego + " already exists.", ex);
      }
      throw ex;
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void edit(Juego juego) throws NonexistentEntityException, Exception {
    juego.getJuegoPK().setJugadoridJugador(juego.getJugador().getIdJugador());
    juego.getJuegoPK().setPartidaidPartida(juego.getPartida().getIdPartida());
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Juego persistentJuego = em.find(Juego.class, juego.getJuegoPK());
      Jugador jugadorOld = persistentJuego.getJugador();
      Jugador jugadorNew = juego.getJugador();
      Partida partidaOld = persistentJuego.getPartida();
      Partida partidaNew = juego.getPartida();
      if (jugadorNew != null) {
        jugadorNew = em.getReference(jugadorNew.getClass(), jugadorNew.getIdJugador());
        juego.setJugador(jugadorNew);
      }
      if (partidaNew != null) {
        partidaNew = em.getReference(partidaNew.getClass(), partidaNew.getIdPartida());
        juego.setPartida(partidaNew);
      }
      juego = em.merge(juego);
      if (jugadorOld != null && !jugadorOld.equals(jugadorNew)) {
        jugadorOld.getJuegoList().remove(juego);
        jugadorOld = em.merge(jugadorOld);
      }
      if (jugadorNew != null && !jugadorNew.equals(jugadorOld)) {
        jugadorNew.getJuegoList().add(juego);
        jugadorNew = em.merge(jugadorNew);
      }
      if (partidaOld != null && !partidaOld.equals(partidaNew)) {
        partidaOld.getJuegoList().remove(juego);
        partidaOld = em.merge(partidaOld);
      }
      if (partidaNew != null && !partidaNew.equals(partidaOld)) {
        partidaNew.getJuegoList().add(juego);
        partidaNew = em.merge(partidaNew);
      }
      em.getTransaction().commit();
    } catch (Exception ex) {
      String msg = ex.getLocalizedMessage();
      if (msg == null || msg.length() == 0) {
        JuegoPK id = juego.getJuegoPK();
        if (findJuego(id) == null) {
          throw new NonexistentEntityException("The juego with id " + id + " no longer exists.");
        }
      }
      throw ex;
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void destroy(JuegoPK id) throws NonexistentEntityException {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Juego juego;
      try {
        juego = em.getReference(Juego.class, id);
        juego.getJuegoPK();
      } catch (EntityNotFoundException enfe) {
        throw new NonexistentEntityException("The juego with id " + id + " no longer exists.", enfe);
      }
      Jugador jugador = juego.getJugador();
      if (jugador != null) {
        jugador.getJuegoList().remove(juego);
        jugador = em.merge(jugador);
      }
      Partida partida = juego.getPartida();
      if (partida != null) {
        partida.getJuegoList().remove(juego);
        partida = em.merge(partida);
      }
      em.remove(juego);
      em.getTransaction().commit();
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public List<Juego> findJuegoEntities() {
    return findJuegoEntities(true, -1, -1);
  }

  public List<Juego> findJuegoEntities(int maxResults, int firstResult) {
    return findJuegoEntities(false, maxResults, firstResult);
  }

  private List<Juego> findJuegoEntities(boolean all, int maxResults, int firstResult) {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      cq.select(cq.from(Juego.class));
      Query q = em.createQuery(cq);
      if (!all) {
        q.setMaxResults(maxResults);
        q.setFirstResult(firstResult);
      }
      return q.getResultList();
    } finally {
      em.close();
    }
  }

  public Juego findJuego(JuegoPK id) {
    EntityManager em = getEntityManager();
    try {
      return em.find(Juego.class, id);
    } finally {
      em.close();
    }
  }

  public int getJuegoCount() {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      Root<Juego> rt = cq.from(Juego.class);
      cq.select(em.getCriteriaBuilder().count(rt));
      Query q = em.createQuery(cq);
      return ((Long) q.getSingleResult()).intValue();
    } finally {
      em.close();
    }
  }
  
}
