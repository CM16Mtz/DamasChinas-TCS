/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladoresjpa;

import controladoresjpa.exceptions.IllegalOrphanException;
import controladoresjpa.exceptions.NonexistentEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import entidades.Estadisticas;
import java.util.ArrayList;
import java.util.List;
import entidades.Marcadores;
import entidades.Chat;
import entidades.Juego;
import entidades.Jugador;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

/**
 *
 * @author HP
 */
public class JugadorJpaController implements Serializable {

  public JugadorJpaController(EntityManagerFactory emf) {
    this.emf = emf;
  }
  private EntityManagerFactory emf = null;

  public EntityManager getEntityManager() {
    return emf.createEntityManager();
  }

  public void create(Jugador jugador) {
    if (jugador.getEstadisticasList() == null) {
      jugador.setEstadisticasList(new ArrayList<Estadisticas>());
    }
    if (jugador.getMarcadoresList() == null) {
      jugador.setMarcadoresList(new ArrayList<Marcadores>());
    }
    if (jugador.getChatList() == null) {
      jugador.setChatList(new ArrayList<Chat>());
    }
    if (jugador.getJuegoList() == null) {
      jugador.setJuegoList(new ArrayList<Juego>());
    }
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      List<Estadisticas> attachedEstadisticasList = new ArrayList<Estadisticas>();
      for (Estadisticas estadisticasListEstadisticasToAttach : jugador.getEstadisticasList()) {
        estadisticasListEstadisticasToAttach = em.getReference(estadisticasListEstadisticasToAttach.getClass(), estadisticasListEstadisticasToAttach.getIdEstadisticas());
        attachedEstadisticasList.add(estadisticasListEstadisticasToAttach);
      }
      jugador.setEstadisticasList(attachedEstadisticasList);
      List<Marcadores> attachedMarcadoresList = new ArrayList<Marcadores>();
      for (Marcadores marcadoresListMarcadoresToAttach : jugador.getMarcadoresList()) {
        marcadoresListMarcadoresToAttach = em.getReference(marcadoresListMarcadoresToAttach.getClass(), marcadoresListMarcadoresToAttach.getIdMarcadores());
        attachedMarcadoresList.add(marcadoresListMarcadoresToAttach);
      }
      jugador.setMarcadoresList(attachedMarcadoresList);
      List<Chat> attachedChatList = new ArrayList<Chat>();
      for (Chat chatListChatToAttach : jugador.getChatList()) {
        chatListChatToAttach = em.getReference(chatListChatToAttach.getClass(), chatListChatToAttach.getIdChat());
        attachedChatList.add(chatListChatToAttach);
      }
      jugador.setChatList(attachedChatList);
      List<Juego> attachedJuegoList = new ArrayList<Juego>();
      for (Juego juegoListJuegoToAttach : jugador.getJuegoList()) {
        juegoListJuegoToAttach = em.getReference(juegoListJuegoToAttach.getClass(), juegoListJuegoToAttach.getJuegoPK());
        attachedJuegoList.add(juegoListJuegoToAttach);
      }
      jugador.setJuegoList(attachedJuegoList);
      em.persist(jugador);
      for (Estadisticas estadisticasListEstadisticas : jugador.getEstadisticasList()) {
        Jugador oldJugadoridJugadorOfEstadisticasListEstadisticas = estadisticasListEstadisticas.getJugadoridJugador();
        estadisticasListEstadisticas.setJugadoridJugador(jugador);
        estadisticasListEstadisticas = em.merge(estadisticasListEstadisticas);
        if (oldJugadoridJugadorOfEstadisticasListEstadisticas != null) {
          oldJugadoridJugadorOfEstadisticasListEstadisticas.getEstadisticasList().remove(estadisticasListEstadisticas);
          oldJugadoridJugadorOfEstadisticasListEstadisticas = em.merge(oldJugadoridJugadorOfEstadisticasListEstadisticas);
        }
      }
      for (Marcadores marcadoresListMarcadores : jugador.getMarcadoresList()) {
        Jugador oldJugadoridJugadorOfMarcadoresListMarcadores = marcadoresListMarcadores.getJugadoridJugador();
        marcadoresListMarcadores.setJugadoridJugador(jugador);
        marcadoresListMarcadores = em.merge(marcadoresListMarcadores);
        if (oldJugadoridJugadorOfMarcadoresListMarcadores != null) {
          oldJugadoridJugadorOfMarcadoresListMarcadores.getMarcadoresList().remove(marcadoresListMarcadores);
          oldJugadoridJugadorOfMarcadoresListMarcadores = em.merge(oldJugadoridJugadorOfMarcadoresListMarcadores);
        }
      }
      for (Chat chatListChat : jugador.getChatList()) {
        Jugador oldJugadoridJugadorOfChatListChat = chatListChat.getJugadoridJugador();
        chatListChat.setJugadoridJugador(jugador);
        chatListChat = em.merge(chatListChat);
        if (oldJugadoridJugadorOfChatListChat != null) {
          oldJugadoridJugadorOfChatListChat.getChatList().remove(chatListChat);
          oldJugadoridJugadorOfChatListChat = em.merge(oldJugadoridJugadorOfChatListChat);
        }
      }
      for (Juego juegoListJuego : jugador.getJuegoList()) {
        Jugador oldJugadorOfJuegoListJuego = juegoListJuego.getJugador();
        juegoListJuego.setJugador(jugador);
        juegoListJuego = em.merge(juegoListJuego);
        if (oldJugadorOfJuegoListJuego != null) {
          oldJugadorOfJuegoListJuego.getJuegoList().remove(juegoListJuego);
          oldJugadorOfJuegoListJuego = em.merge(oldJugadorOfJuegoListJuego);
        }
      }
      em.getTransaction().commit();
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void edit(Jugador jugador) throws IllegalOrphanException, NonexistentEntityException, Exception {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Jugador persistentJugador = em.find(Jugador.class, jugador.getIdJugador());
      List<Estadisticas> estadisticasListOld = persistentJugador.getEstadisticasList();
      List<Estadisticas> estadisticasListNew = jugador.getEstadisticasList();
      List<Marcadores> marcadoresListOld = persistentJugador.getMarcadoresList();
      List<Marcadores> marcadoresListNew = jugador.getMarcadoresList();
      List<Chat> chatListOld = persistentJugador.getChatList();
      List<Chat> chatListNew = jugador.getChatList();
      List<Juego> juegoListOld = persistentJugador.getJuegoList();
      List<Juego> juegoListNew = jugador.getJuegoList();
      List<String> illegalOrphanMessages = null;
      for (Estadisticas estadisticasListOldEstadisticas : estadisticasListOld) {
        if (!estadisticasListNew.contains(estadisticasListOldEstadisticas)) {
          if (illegalOrphanMessages == null) {
            illegalOrphanMessages = new ArrayList<String>();
          }
          illegalOrphanMessages.add("You must retain Estadisticas " + estadisticasListOldEstadisticas + " since its jugadoridJugador field is not nullable.");
        }
      }
      for (Marcadores marcadoresListOldMarcadores : marcadoresListOld) {
        if (!marcadoresListNew.contains(marcadoresListOldMarcadores)) {
          if (illegalOrphanMessages == null) {
            illegalOrphanMessages = new ArrayList<String>();
          }
          illegalOrphanMessages.add("You must retain Marcadores " + marcadoresListOldMarcadores + " since its jugadoridJugador field is not nullable.");
        }
      }
      for (Chat chatListOldChat : chatListOld) {
        if (!chatListNew.contains(chatListOldChat)) {
          if (illegalOrphanMessages == null) {
            illegalOrphanMessages = new ArrayList<String>();
          }
          illegalOrphanMessages.add("You must retain Chat " + chatListOldChat + " since its jugadoridJugador field is not nullable.");
        }
      }
      for (Juego juegoListOldJuego : juegoListOld) {
        if (!juegoListNew.contains(juegoListOldJuego)) {
          if (illegalOrphanMessages == null) {
            illegalOrphanMessages = new ArrayList<String>();
          }
          illegalOrphanMessages.add("You must retain Juego " + juegoListOldJuego + " since its jugador field is not nullable.");
        }
      }
      if (illegalOrphanMessages != null) {
        throw new IllegalOrphanException(illegalOrphanMessages);
      }
      List<Estadisticas> attachedEstadisticasListNew = new ArrayList<Estadisticas>();
      for (Estadisticas estadisticasListNewEstadisticasToAttach : estadisticasListNew) {
        estadisticasListNewEstadisticasToAttach = em.getReference(estadisticasListNewEstadisticasToAttach.getClass(), estadisticasListNewEstadisticasToAttach.getIdEstadisticas());
        attachedEstadisticasListNew.add(estadisticasListNewEstadisticasToAttach);
      }
      estadisticasListNew = attachedEstadisticasListNew;
      jugador.setEstadisticasList(estadisticasListNew);
      List<Marcadores> attachedMarcadoresListNew = new ArrayList<Marcadores>();
      for (Marcadores marcadoresListNewMarcadoresToAttach : marcadoresListNew) {
        marcadoresListNewMarcadoresToAttach = em.getReference(marcadoresListNewMarcadoresToAttach.getClass(), marcadoresListNewMarcadoresToAttach.getIdMarcadores());
        attachedMarcadoresListNew.add(marcadoresListNewMarcadoresToAttach);
      }
      marcadoresListNew = attachedMarcadoresListNew;
      jugador.setMarcadoresList(marcadoresListNew);
      List<Chat> attachedChatListNew = new ArrayList<Chat>();
      for (Chat chatListNewChatToAttach : chatListNew) {
        chatListNewChatToAttach = em.getReference(chatListNewChatToAttach.getClass(), chatListNewChatToAttach.getIdChat());
        attachedChatListNew.add(chatListNewChatToAttach);
      }
      chatListNew = attachedChatListNew;
      jugador.setChatList(chatListNew);
      List<Juego> attachedJuegoListNew = new ArrayList<Juego>();
      for (Juego juegoListNewJuegoToAttach : juegoListNew) {
        juegoListNewJuegoToAttach = em.getReference(juegoListNewJuegoToAttach.getClass(), juegoListNewJuegoToAttach.getJuegoPK());
        attachedJuegoListNew.add(juegoListNewJuegoToAttach);
      }
      juegoListNew = attachedJuegoListNew;
      jugador.setJuegoList(juegoListNew);
      jugador = em.merge(jugador);
      for (Estadisticas estadisticasListNewEstadisticas : estadisticasListNew) {
        if (!estadisticasListOld.contains(estadisticasListNewEstadisticas)) {
          Jugador oldJugadoridJugadorOfEstadisticasListNewEstadisticas = estadisticasListNewEstadisticas.getJugadoridJugador();
          estadisticasListNewEstadisticas.setJugadoridJugador(jugador);
          estadisticasListNewEstadisticas = em.merge(estadisticasListNewEstadisticas);
          if (oldJugadoridJugadorOfEstadisticasListNewEstadisticas != null && !oldJugadoridJugadorOfEstadisticasListNewEstadisticas.equals(jugador)) {
            oldJugadoridJugadorOfEstadisticasListNewEstadisticas.getEstadisticasList().remove(estadisticasListNewEstadisticas);
            oldJugadoridJugadorOfEstadisticasListNewEstadisticas = em.merge(oldJugadoridJugadorOfEstadisticasListNewEstadisticas);
          }
        }
      }
      for (Marcadores marcadoresListNewMarcadores : marcadoresListNew) {
        if (!marcadoresListOld.contains(marcadoresListNewMarcadores)) {
          Jugador oldJugadoridJugadorOfMarcadoresListNewMarcadores = marcadoresListNewMarcadores.getJugadoridJugador();
          marcadoresListNewMarcadores.setJugadoridJugador(jugador);
          marcadoresListNewMarcadores = em.merge(marcadoresListNewMarcadores);
          if (oldJugadoridJugadorOfMarcadoresListNewMarcadores != null && !oldJugadoridJugadorOfMarcadoresListNewMarcadores.equals(jugador)) {
            oldJugadoridJugadorOfMarcadoresListNewMarcadores.getMarcadoresList().remove(marcadoresListNewMarcadores);
            oldJugadoridJugadorOfMarcadoresListNewMarcadores = em.merge(oldJugadoridJugadorOfMarcadoresListNewMarcadores);
          }
        }
      }
      for (Chat chatListNewChat : chatListNew) {
        if (!chatListOld.contains(chatListNewChat)) {
          Jugador oldJugadoridJugadorOfChatListNewChat = chatListNewChat.getJugadoridJugador();
          chatListNewChat.setJugadoridJugador(jugador);
          chatListNewChat = em.merge(chatListNewChat);
          if (oldJugadoridJugadorOfChatListNewChat != null && !oldJugadoridJugadorOfChatListNewChat.equals(jugador)) {
            oldJugadoridJugadorOfChatListNewChat.getChatList().remove(chatListNewChat);
            oldJugadoridJugadorOfChatListNewChat = em.merge(oldJugadoridJugadorOfChatListNewChat);
          }
        }
      }
      for (Juego juegoListNewJuego : juegoListNew) {
        if (!juegoListOld.contains(juegoListNewJuego)) {
          Jugador oldJugadorOfJuegoListNewJuego = juegoListNewJuego.getJugador();
          juegoListNewJuego.setJugador(jugador);
          juegoListNewJuego = em.merge(juegoListNewJuego);
          if (oldJugadorOfJuegoListNewJuego != null && !oldJugadorOfJuegoListNewJuego.equals(jugador)) {
            oldJugadorOfJuegoListNewJuego.getJuegoList().remove(juegoListNewJuego);
            oldJugadorOfJuegoListNewJuego = em.merge(oldJugadorOfJuegoListNewJuego);
          }
        }
      }
      em.getTransaction().commit();
    } catch (Exception ex) {
      String msg = ex.getLocalizedMessage();
      if (msg == null || msg.length() == 0) {
        Integer id = jugador.getIdJugador();
        if (findJugador(id) == null) {
          throw new NonexistentEntityException("The jugador with id " + id + " no longer exists.");
        }
      }
      throw ex;
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
    EntityManager em = null;
    try {
      em = getEntityManager();
      em.getTransaction().begin();
      Jugador jugador;
      try {
        jugador = em.getReference(Jugador.class, id);
        jugador.getIdJugador();
      } catch (EntityNotFoundException enfe) {
        throw new NonexistentEntityException("The jugador with id " + id + " no longer exists.", enfe);
      }
      List<String> illegalOrphanMessages = null;
      List<Estadisticas> estadisticasListOrphanCheck = jugador.getEstadisticasList();
      for (Estadisticas estadisticasListOrphanCheckEstadisticas : estadisticasListOrphanCheck) {
        if (illegalOrphanMessages == null) {
          illegalOrphanMessages = new ArrayList<String>();
        }
        illegalOrphanMessages.add("This Jugador (" + jugador + ") cannot be destroyed since the Estadisticas " + estadisticasListOrphanCheckEstadisticas + " in its estadisticasList field has a non-nullable jugadoridJugador field.");
      }
      List<Marcadores> marcadoresListOrphanCheck = jugador.getMarcadoresList();
      for (Marcadores marcadoresListOrphanCheckMarcadores : marcadoresListOrphanCheck) {
        if (illegalOrphanMessages == null) {
          illegalOrphanMessages = new ArrayList<String>();
        }
        illegalOrphanMessages.add("This Jugador (" + jugador + ") cannot be destroyed since the Marcadores " + marcadoresListOrphanCheckMarcadores + " in its marcadoresList field has a non-nullable jugadoridJugador field.");
      }
      List<Chat> chatListOrphanCheck = jugador.getChatList();
      for (Chat chatListOrphanCheckChat : chatListOrphanCheck) {
        if (illegalOrphanMessages == null) {
          illegalOrphanMessages = new ArrayList<String>();
        }
        illegalOrphanMessages.add("This Jugador (" + jugador + ") cannot be destroyed since the Chat " + chatListOrphanCheckChat + " in its chatList field has a non-nullable jugadoridJugador field.");
      }
      List<Juego> juegoListOrphanCheck = jugador.getJuegoList();
      for (Juego juegoListOrphanCheckJuego : juegoListOrphanCheck) {
        if (illegalOrphanMessages == null) {
          illegalOrphanMessages = new ArrayList<String>();
        }
        illegalOrphanMessages.add("This Jugador (" + jugador + ") cannot be destroyed since the Juego " + juegoListOrphanCheckJuego + " in its juegoList field has a non-nullable jugador field.");
      }
      if (illegalOrphanMessages != null) {
        throw new IllegalOrphanException(illegalOrphanMessages);
      }
      em.remove(jugador);
      em.getTransaction().commit();
    } finally {
      if (em != null) {
        em.close();
      }
    }
  }

  public List<Jugador> findJugadorEntities() {
    return findJugadorEntities(true, -1, -1);
  }

  public List<Jugador> findJugadorEntities(int maxResults, int firstResult) {
    return findJugadorEntities(false, maxResults, firstResult);
  }

  private List<Jugador> findJugadorEntities(boolean all, int maxResults, int firstResult) {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      cq.select(cq.from(Jugador.class));
      Query q = em.createQuery(cq);
      if (!all) {
        q.setMaxResults(maxResults);
        q.setFirstResult(firstResult);
      }
      return q.getResultList();
    } finally {
      em.close();
    }
  }

  public Jugador findJugador(Integer id) {
    EntityManager em = getEntityManager();
    try {
      return em.find(Jugador.class, id);
    } finally {
      em.close();
    }
  }

  public int getJugadorCount() {
    EntityManager em = getEntityManager();
    try {
      CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
      Root<Jugador> rt = cq.from(Jugador.class);
      cq.select(em.getCriteriaBuilder().count(rt));
      Query q = em.createQuery(cq);
      return ((Long) q.getSingleResult()).intValue();
    } finally {
      em.close();
    }
  }
  
  public Jugador validarJugador(Jugador jugador) {
    EntityManager em = getEntityManager();
    Jugador auxiliar = (Jugador) em.createQuery("SELECT c FROM Jugador c WHERE "
        + "c.nombreJugador = :nombreJugador AND c.contrasena = :contrasena")
        .setParameter("nombreJugador", jugador.getNombreJugador())
        .setParameter("contrasena", jugador.getContrasena())
        .getSingleResult();
    return auxiliar;
  }
  
}
